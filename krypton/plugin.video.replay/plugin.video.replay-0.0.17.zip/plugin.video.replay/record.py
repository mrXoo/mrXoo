# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs


xbmc.executebuiltin('xbmc.playercontrol(stop)')
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.replay/record_last/)")
