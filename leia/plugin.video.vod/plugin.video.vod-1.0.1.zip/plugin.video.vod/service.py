# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))
def movies():
	root= xbmc.translatePath('special://home/userdata/playlists/video/')
	#url = 'https://www.midian.appboxes.co/wolfyB/newmidian/Movies/megalist.m3u' 
	url = 'https://www.dropbox.com/s/x32dtcvm23mruyy/movies.m3u?dl=1'    
	#os.makedirs(root, exist_ok=True) 		
	fileName = (os.path.join(root,'movies.m3u'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()

def tvshows():
	root= xbmc.translatePath('special://home/userdata/playlists/video/')
	#url = 'https://www.midian.appboxes.co/wolfyB/newmidian/TVShows/tvseries.m3u'     
	url = 'https://www.dropbox.com/s/ska0tdvwep9kf1d/tvshows.m3u?dl=1'  
	#os.makedirs(root, exist_ok=True) 		
	fileName = (os.path.join(root,'tvshows.m3u'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()
	
movies()
tvshows()
xbmc.executebuiltin('library://video/playlists.xml/')
