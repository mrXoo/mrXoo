# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time
import xbmc, sys
xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.video.nhlstreams/'))


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('plugin.video.nhlstreams')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:

	    time.sleep(30)
	    #xbmcvfs.copy('special://home/addons/plugin.video.nhlstreams/resources/hosts.conf','D:/KODI/portable_data/userdata/addon_data/plugin.video.nhlstreams/hosts.conf')
	    xbmcvfs.copy('special://home/addons/plugin.video.nhlstreams/resources/hosts.conf','/storage/.config/hosts.conf')		
	    #xbmcvfs.copy('special://home/addons/plugin.video.nhlstreams/resources/hosts','D:/KODI/portable_data/userdata/addon_data/plugin.video.nhlstreams/hosts')
	    xbmcvfs.copy('special://home/addons/plugin.video.nhlstreams/resources/hosts','/etc/hosts')
	    xbmcvfs.copy('special://home/addons/plugin.video.nhlstreams/hosts/settings.xml','special://profile/addon_data/plugin.video.nhlstreams/settings.xml')
