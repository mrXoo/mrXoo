import xbmc,xbmcaddon,xbmcvfs,xbmcgui
import os
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
import time




def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)



dialog = xbmcgui.Dialog().select('KODI CONFIG SETTINGS', ['Power Menu','Open Kodi Settings','Open File Manager','Configure WiFi Settings','Configure Trakt','Configure Real Debrid','Downloader'])
if dialog==0:
	xbmc.executebuiltin('ActivateWindow(shutdownmenu)')

elif dialog==1:
	xbmc.executebuiltin('ActivateWindow(Settings)')

elif dialog==2:
	xbmc.executebuiltin('ActivateWindow(filemanager)')

elif dialog==3:
	xbmcgui.Dialog().ok('CoreELEC SETTINGS', 'Scroll to Connections and select your WiFi. Addon will open once you click OK')
	xbmc.executebuiltin('RunAddon(service.coreelec.settings)')

	
elif dialog==4:
	dialog = xbmcgui.Dialog().select('TRAKT SETTINGS', ['Configure Trakt Settings','Configure Movie DB Trakt Settings'])
	if dialog==0:
		xbmc.executebuiltin('Addon.OpenSettings(script.trakt)')
		xbmcgui.Dialog().ok('TRAKT ADDON', 'click the box How do I authorizethe Trakt addon, then enter the code in on your device as stated')

	elif dialog==1:
		xbmc.executebuiltin('Addon.OpenSettings( plugin.video.themoviedb.helper,Accounts)')
		xbmcgui.Dialog().ok('THE MOVIE DB HELPER ADDON', 'Scroll to Accounts Tab. Click the box to Authenticate Trakt Account... then enter the code in on your device as stated')
		
elif dialog==5:
	dialog = xbmcgui.Dialog().select('REAL DEBRID SETTINGS', ['Configure Shadow, The Oath, 4K Settings','Configure Fen Settings','Configure FoxyStreams Settings','Configure Seren Settings','Configure Realizer Settings','Re-Sync all and Reboot'])
	if dialog==0:
		xbmc.executebuiltin('Addon.OpenSettings(script.module.resolveurl)')
		xbmcgui.Dialog().ok('RESOLVE URL SETTINGS', 'Scroll to Universal Resolvers Tab. Scroll ALL the way down to REAL-DEBRID and click (Re)Authorize My Account.')

	elif dialog==1:
		xbmc.executebuiltin('Addon.OpenSettings(script.module.myaccounts)')
		xbmcgui.Dialog().ok('FEN ADDON', 'Scroll to Debrid Accounts Tab. Scroll to REAL-DEBRID and click Authorize. Enter the code on your device.')
		
	if dialog==2:
		xbmc.executebuiltin('RunAddon(plugin.video.foxystreams)')
		xbmcgui.Dialog().ok('FOXYSTREAMS ADDON', 'Enter the CODE on your device.')

	elif dialog==3:
		xbmc.executebuiltin('Addon.OpenSettings(plugin.video.seren)')
		xbmcgui.Dialog().ok('SEREN ADDON', 'Scroll to Accounts Tab. Scroll to REAL-DEBRID. Click Authorize Real-Debrid.... Enter the CODE on your device.')
	elif dialog==4:
		xbmc.executebuiltin('Addon.OpenSettings(plugin.video.realizer)')
		xbmcgui.Dialog().ok('REALIZER ADDON', 'Click Authorize and enter the CODE on your device.')
	elif dialog==5:
		xbmc.executebuiltin("ActivateWindow(10025,plugin://script.module.fenomscrapers/?action=syncMyAccount)")
		time.sleep(5)
		dialog = xbmcgui.Dialog()
		dialog.notification('BOX SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		xbmc.executebuiltin(Reboot)
		
elif dialog==6:
	dialog = xbmcgui.Dialog().select('REAL DEBRID DOWNLOADER', ['Realizer Download area','Fen real debrid Download area'])

	if dialog==0:
		dialog = xbmcgui.Dialog().select('Realizer Downloader', ['Realizer links','Realizer Torrents'])
			
		if dialog==0:
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.realizer/?action=rdTransfers&page=1,return)')
			xbmcgui.Dialog().ok('REALIZER DOWNLOADER','On the next page press menu key or C on the link you want to download and select download from Cloud.')		
		elif dialog==1:
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.realizer/?action=rdTorrentList&page=1,return)')
			xbmcgui.Dialog().ok('REALIZER DOWNLOADER', 'On the next page open the folder/link then select press menu key or C and select download from Cloud.')
	elif dialog==1:
		dialog = xbmcgui.Dialog().select('FEN Downloader', ['FEN Links','FEN Torrents'])	
		if dialog==0:
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.fen/?mode=real_debrid.rd_downloads,return)')
			xbmcgui.Dialog().ok('FEN DOWNLOADER','On the next page press menu key or C on the link you want to download and select download.')		
		elif dialog==1:	
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.fen/?mode=real_debrid.rd_torrent_cloud,return)')
			xbmcgui.Dialog().ok('FEN DOWNLOADER','On the next page open the folder then select press menu key or C and select download File.')
