import os

xbmc.executebuiltin('RunAddon(plugin.video.kemo)')