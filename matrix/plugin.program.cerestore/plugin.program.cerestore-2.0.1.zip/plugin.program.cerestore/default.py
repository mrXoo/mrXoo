# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))


choice = xbmcgui.Dialog().yesno('MATRIX BUILD RESTORE', 'Would you like to download and fresh MATRIX build now?', nolabel='NO',yeslabel='YES')
if choice == 0:
	xbmc.executebuiltin("Home")
elif choice == 1:  
	dialog = xbmcgui.Dialog()
	dialog.ok("MATRIX BUILD RESTORE", "[COLOR red][B]!!!ATTENTION!!![/B][/COLOR] IT WILL TAKE SOME TIME TO COMPLETE THE DOWNLOAD PLEASE BE PATIENT")           
	url = 'https://www.dropbox.com/s/6h4v5u8iscuxvjp/matrix.tar?dl=1'     
	os.makedirs('storage/.restore/', exist_ok=True) 		
	fileName = (os.path.join('storage/.restore','20210903185157.tar'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()
	dialog = xbmcgui.Dialog()
	dialog.ok("MATRIX BUILD RESTORE", "[COLOR red][B]!!!ATTENTION!!![/B][/COLOR] YOU WILL HAVE TO RECONNECT TO WIFI AND RE-AUTHOURIZE YOUR STREAMING ACCOUNTS. BOX WILL NOW REBOOT")
	dialog = xbmcgui.Dialog()
	dialog.ok("MATRIX BUILD RESTORE", "PRESS [B]OK[/B] TO ENABLE A REBOOT [COLOR red][B]!!!WARNING!!![/B][/COLOR] DO NOT POWER OFF BOX WHEN UPDATE IS IN PROGRESS")
	time.sleep(2)	
	xbmc.executebuiltin('Reboot')
	#xbmc.executebuiltin("Home")