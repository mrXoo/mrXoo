# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
import xbmc
import os

xbmc.log(repr(sys.argv))

################## COPY FROM SCRIPT.TRAKT TO MOVIEDB.HELPER ###############################
if os.path.exists('xbmc.translatePath("special://home/addons/plugin.video.themoviedb.helper")'):
	script_trakt = xbmcaddon.Addon("script.trakt") #from
	moviedb_helper = xbmcaddon.Addon("plugin.video.themoviedb.helper") #to

	auth = script_trakt.getSetting("authorization") #from setting
	moviedb_helper.setSetting("trakt_token", auth) #to setting

	user= script_trakt.getSetting("user")
	slug= '%s | %s' %(user,user)
	moviedb_helper.setSetting("monitor_userslug", slug)





################## COPY TO MY ACCOUNTS ###############################
if os.path.exists('xbmc.translatePath("special://home/addons/script.module.myaccounts")'):
	authorize = xbmcaddon.Addon("script.module.authorize") #from
	myaccounts = xbmcaddon.Addon("script.module.myaccounts") #to

	token = authorize.getSetting("realdebrid.token") #from setting
	myaccounts.setSetting("realdebrid.token", token) #to setting

	client_id = authorize.getSetting("realdebrid.client_id") #from setting
	myaccounts.setSetting("realdebrid.client_id", client_id) #to setting

	refresh = authorize.getSetting("realdebrid.refresh") #from setting
	myaccounts.setSetting("realdebrid.refresh", refresh) #to setting

	secret = authorize.getSetting("realdebrid.secret") #from setting
	myaccounts.setSetting("realdebrid.secret", secret) #to setting

	user = authorize.getSetting("realdebrid.username") #from setting
	myaccounts.setSetting("realdebrid.username", user) #to setting

################## COPY TO RESOLVEURL ###############################
if os.path.exists('xbmc.translatePath("special://home/addons/script.module.resolveurl")'):
	authorize = xbmcaddon.Addon("script.module.authorize") #from
	resolveurl = xbmcaddon.Addon("script.module.resolveurl") #to

	token = authorize.getSetting("realdebrid.token") #from setting
	resolveurl.setSetting("RealDebridResolver_token", token) #to setting

	client_id = authorize.getSetting("realdebrid.client_id") #from setting
	resolveurl.setSetting("RealDebridResolver_client_id", client_id) #to setting

	refresh = authorize.getSetting("realdebrid.refresh") #from setting
	resolveurl.setSetting("RealDebridResolver_refresh", refresh) #to setting

	secret = authorize.getSetting("realdebrid.secret") #from setting
	resolveurl.setSetting("RealDebridResolver_client_secret", secret) #to setting

################## COPY TO SEREN ###############################
if os.path.exists('xbmc.translatePath("special://home/addons/plugin.video.seren")")'):
	authorize = xbmcaddon.Addon("script.module.authorize") #from
	seren = xbmcaddon.Addon("plugin.video.seren") #to

	user = authorize.getSetting("realdebrid.username") #from setting
	seren.setSetting("rd.username", user) #to setting

	token = authorize.getSetting("realdebrid.token") #from setting
	seren.setSetting("rd.auth", token) #to setting

	client_id = authorize.getSetting("realdebrid.client_id") #from setting
	seren.setSetting("rd.client_id", client_id) #to setting

	refresh = authorize.getSetting("realdebrid.refresh") #from setting
	seren.setSetting("rd.refresh", refresh) #to setting

	secret = authorize.getSetting("realdebrid.secret") #from setting
	seren.setSetting("rd.secret", secret) #to setting

	true = ("true")
	seren.setSetting("realdebrid.enabled", true) #to setting

################## COPY TO FOXY ###############################
if os.path.exists('xbmc.translatePath("special://home/addons/plugin.video.foxystreams")'):
	authorize = xbmcaddon.Addon("script.module.authorize") #from
	foxy = xbmcaddon.Addon("plugin.video.foxystreams") #to

	token = authorize.getSetting("realdebrid.token") #from setting
	foxy.setSetting("RealDebrid.api_key", token) #to setting

	client_id = authorize.getSetting("realdebrid.client_id") #from setting
	foxy.setSetting("RealDebrid.client_id", client_id) #to setting

	refresh = authorize.getSetting("realdebrid.refresh") #from setting
	foxy.setSetting("RealDebrid.refresh_token", refresh) #to setting

	secret = authorize.getSetting("realdebrid.secret") #from setting
	foxy.setSetting("RealDebrid.client_secret", secret) #to setting

############################ RESYNC FEN AND REBOOT ###################################################
time.sleep(1)
xbmc.executebuiltin("ActivateWindow(10025,plugin://script.module.fenomscrapers/?action=syncMyAccount)")
time.sleep(5)
dialog = xbmcgui.Dialog()
dialog.notification('BOX SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
time.sleep(5)
xbmc.executebuiltin('reboot')