# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.lebuildrestore/'))
xbmc.executebuiltin('RunAddon(plugin.program.cerestore)')