import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs

dialog = xbmcgui.Dialog().select('TO FILTER RESULTS NEXT SCREEN SCROLL LEFT TWICE AND CLICK FILTER', ['Browse Movies','Browse TV Shows'])
if dialog==0:
	xbmc.executebuiltin('Dialog.Close(busydialog)')
	xbmc.executebuiltin('ActivateWindow(10028,special://profile/playlists/video/movies.m3u,return)')

elif dialog==1:
	xbmc.executebuiltin('Dialog.Close(busydialog)')
	xbmc.executebuiltin('ActivateWindow(10028,special://profile/playlists/video/tvshows.m3u,return)')

