from xbmcswift2 import Plugin
import xbmc,xbmcplugin,xbmcaddon,xbmcvfs,xbmcgui
import requests
import requests_cache
import re
import sys
import json
import time
import html



def log(v):
    xbmc.log(repr(v), xbmc.LOGERROR)

def addon_id():
    return xbmcaddon.Addon().getAddonInfo('id')

def get_icon_path(icon_name):
    if plugin.get_setting('user.icons') == "true":
        user_icon = "special://profile/addon_data/%s/icons/%s.png" % (addon_id(),icon_name)
        if xbmcvfs.exists(user_icon):
            return user_icon
    return "special://home/addons/%s/resources/img/%s.png" % (addon_id(),icon_name)

requests_cache.install_cache(xbmc.translatePath(f"special://profile/addon_data/{addon_id()}/fmstream_cache" ), expire_after=360)
plugin = Plugin()


def fmstream(query,offset):
    keya = 0x3ee9;
    keyb = 0x21ff;
    key = round(keya * int(time.time()) + keyb);

    url = f"http://fmstream.org/index.php?hq=1&{query}&key={key:x}&n={offset}";
    if plugin.get_setting('hq') == "true":
        url = f"{url}&hq=1"
    order = plugin.get_setting('order')
    if order == "Big":
        url = f"{url}&o=big"
    elif order == "Medium":
        url = f"{url}&o=med"
    elif order == "Small":
        url = f"{url}&o=sma"
    t = requests.get(url).text
    t = html.unescape(t)
    t = t.splitlines()[3:]
    j = json.loads(t[0])
    data = j["data"]
    return data


@plugin.route('/fmstream_urls/<query>/<id>/<offset>')
def fmstream_urls(query,id,offset):
    data = fmstream(query,offset)
    station = [x for x in data if x['id'] == id][0]
    itu = station.get("itu","xxx")
    thumbnail = "special://home/addons/%s/resources/png/%s.png" % (addon_id(),itu.lower())
    if not xbmcvfs.exists(thumbnail):
        thumbnail = get_icon_path('radio')
    items = []
    for url in station["urls"]:
        items.append(
        {
            'label': f'{station["program"]} - {url.get("br","0")}kbps {url.get("sr","0")}khz - {url["url"]}',
            'path': url["url"],
            'thumbnail': thumbnail,
            'info_type': 'music',
            'info':{"mediatype": "music"} ,
            'is_playable': True,
        })
    return items


@plugin.route('/stations/<key>/<value>/<offset>')
def stations(key,value,offset):
    if value == "RD":
        requests_cache.uninstall_cache()
    query = f"{key}={value}"
    data = fmstream(query,offset)
    items = []
    for station in data:
        program = station["program"]
        id = station["id"]
        label = f"{program}"
        itu = station.get("itu","xxx")
        thumbnail = "special://home/addons/%s/resources/png/%s.png" % (addon_id(),itu.lower())
        if not xbmcvfs.exists(thumbnail):
            thumbnail = get_icon_path('radio')
        if plugin.get_setting('extra') == "true":
            style = station.get('style')
            if style:
                label += f" - [COLOR green]{style}[/COLOR]"
            city = station.get('city')
            if city:
                label += f" - [COLOR red]{city}[/COLOR]"
            slogan = station.get('slogan')
            if slogan:
                label += f" - [COLOR blue]{slogan}[/COLOR]"
            description = station.get('description')
            if description:
                label += f" - [COLOR darkgrey]{description}[/COLOR]"
        items.append(
        {
            'label': label,
            'path': plugin.url_for(fmstream_urls, query=query, id=id, offset=offset),
            'thumbnail': thumbnail,
            'info_type': 'music',
            'info':{"mediatype": "music"}
        })
    if len(data) == 101:
        offset = int(offset) + 101
        items.append(
        {
            'label': "Next Page",
            'path': plugin.url_for(stations, key=key, value=value, offset=offset),
            'thumbnail':  get_icon_path('nextpage')
        })
    return items


@plugin.route('/countries')
def countries():
    r = requests.get("http://fmstream.org/country.htm")
    r.encoding = r.apparent_encoding
    html = r.text
    found = re.findall(r'<a href="(.*?)".*?>(.*?)</a',html)
    items = []
    for match in found:
        query = re.search(r'c=(.*?)&', match[0])
        if query:
            code = query.group(1)
            name = match[1]
            thumbnail = "special://home/addons/%s/resources/png/%s.png" % (addon_id(),code.lower())
            items.append(
            {
                'label': name,
                'path': plugin.url_for(stations, key="c", value=code, offset=0),
                'thumbnail':  thumbnail
            })
    return items


@plugin.route('/languages')
def languages():
    html = requests.get("http://fmstream.org/language.htm").text
    found = re.findall(r'<a href="(.*?)".*?>(.*?)</a',html)
    items = []
    for match in found:
        query = re.search(r'l=(.*?)&', match[0])
        if query:
            code = query.group(1)
            name = match[1]
            items.append(
            {
                'label': name,
                'path': plugin.url_for(stations, key="l", value=code, offset=0),
                'thumbnail': get_icon_path('genre_talk'),
            })
    return items


@plugin.route('/styles')
def styles():
    html = requests.get("http://fmstream.org/style.htm").text
    found = re.findall(r'<a href="(.*?)".*?>(.*?)</a',html)
    items = []
    for match in found:
        query = re.search(r'style=(.*?)&', match[0])
        if query:
            code = query.group(1)
            name = match[1]
            items.append(
            {
                'label': name,
                'path': plugin.url_for(stations, key="style", value=code, offset=0),
                'thumbnail': get_icon_path('genre_music'),
            })
    return items


@plugin.route('/search_dialog')
def search_dialog():
    d = xbmcgui.Dialog()
    what = d.input("Search")
    if what:
        return stations("s",what, offset=0)



@plugin.route('/')
def index():
    items = []

    items.append(
    {
        'label': "Featured",
        'path': plugin.url_for(stations, key="c", value="FT", offset=0),
        'thumbnail':  get_icon_path('favourites')
    })
    items.append(
    {
        'label': "Countries",
        'path': plugin.url_for(countries),
        'thumbnail': get_icon_path('genre_foreign'),
    })
    items.append(
    {
        'label': "Languages",
        'path': plugin.url_for(languages),
        'thumbnail': get_icon_path('genre_talk'),
    })
    items.append(
    {
        'label': "Styles",
        'path': plugin.url_for(styles),
        'thumbnail': get_icon_path('genre_music'),
    })
    items.append(
    {
        'label': "Search",
        'path': plugin.url_for(search_dialog),
        'thumbnail': get_icon_path('search'),
    })
    items.append(
    {
        'label': "Random",
        'path': plugin.url_for(stations, key="c", value="RD", offset=0),
        'thumbnail':  get_icon_path('faq8')
    })
    return items



if __name__ == '__main__':
    plugin.run()
