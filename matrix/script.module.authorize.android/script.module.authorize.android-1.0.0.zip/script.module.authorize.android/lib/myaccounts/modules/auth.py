# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
import xbmc
import os

xbmc.log(repr(sys.argv))


def main():
	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/script.firstrun/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "script.logviewer","enabled":true}}') 
	xbmc.sleep(200)
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "script.startup","enabled":true}}') 
	xbmc.sleep(200)
	trakt()


################## COPY FROM MOVIEDB.HELPER TO SCRIPT.TRAKT ###############################
def trakt(): ##### SCRIPT.TRAKT needs the same API as MOVIEDB.HELPER to work
	try:

		moviedb_helper = xbmcaddon.Addon("plugin.video.themoviedb.helper") #from
		script_trakt = xbmcaddon.Addon("script.trakt") #to

		auth = moviedb_helper.getSetting("trakt_token") #from setting
		script_trakt.setSetting("authorization", auth) #to setting

		# user= script_trakt.getSetting("user")
		# slug= '%s | %s' %(user,user)
		# moviedb_helper.setSetting("monitor_userslug", slug)
		myaccounts()

	except:
		myaccounts()
		

	################## COPY TO MY ACCOUNTS ###############################
def myaccounts():
	try:

		authorize = xbmcaddon.Addon("script.module.authorize.android") #from
		myaccounts = xbmcaddon.Addon("script.module.myaccounts") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		myaccounts.setSetting("realdebrid.token", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		myaccounts.setSetting("realdebrid.client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		myaccounts.setSetting("realdebrid.refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		myaccounts.setSetting("realdebrid.secret", secret) #to setting

		user = authorize.getSetting("realdebrid.username") #from setting
		myaccounts.setSetting("realdebrid.username", user) #to setting
		shadow()
	except:
		shadow()
		
	################## COPY TO SHADOW ###############################
def shadow():
	try:
		authorize = xbmcaddon.Addon("script.module.authorize.android") #from
		shadow = xbmcaddon.Addon("plugin.video.shadow") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		shadow.setSetting("rd.auth", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		shadow.setSetting("rd.client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		shadow.setSetting("rd.refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		shadow.setSetting("rd.secret", secret) #to setting
		
		true = ("true")
		shadow.setSetting("debrid_use", true) #to setting
		
		resolve()		
	except:
		resolve()
	################## COPY TO RESOLVEURL ###############################
def resolve():
	try:
		authorize = xbmcaddon.Addon("script.module.authorize.android") #from
		resolveurl = xbmcaddon.Addon("script.module.resolveurl") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		resolveurl.setSetting("RealDebridResolver_token", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		resolveurl.setSetting("RealDebridResolver_client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		resolveurl.setSetting("RealDebridResolver_refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		resolveurl.setSetting("RealDebridResolver_client_secret", secret) #to setting
		
		true = ("true")
		resolveurl.setSetting("RealDebridResolver_enabled", true) #to setting
		
		seren()		
	except:
		seren()
	################## COPY TO SEREN ###############################
def seren():
	try:
		authorize = xbmcaddon.Addon("script.module.authorize.android") #from
		seren = xbmcaddon.Addon("plugin.video.seren") #to

		user = authorize.getSetting("realdebrid.username") #from setting
		seren.setSetting("rd.username", user) #to setting

		token = authorize.getSetting("realdebrid.token") #from setting
		seren.setSetting("rd.auth", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		seren.setSetting("rd.client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		seren.setSetting("rd.refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		seren.setSetting("rd.secret", secret) #to setting

		true = ("true")
		seren.setSetting("realdebrid.enabled", true) #to setting
		
		download = ("var/media/KODI/")
		seren.setSetting("download.location", download) #to setting		
		foxy()
	except:
		foxy()
	################## COPY TO FOXY ###############################
def foxy():
	try:
		authorize = xbmcaddon.Addon("script.module.authorize.android") #from
		foxy = xbmcaddon.Addon("plugin.video.foxystreams") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		foxy.setSetting("RealDebrid.api_key", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		foxy.setSetting("RealDebrid.client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		foxy.setSetting("RealDebrid.refresh_token", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		foxy.setSetting("RealDebrid.client_secret", secret) #to setting
		
		true = ("true")
		foxy.setSetting("debrid_enabled.RealDebrid", true) #to setting
		
		realdebrid()
	except:
		realdebrid()
	################## COPY TO REAL DEBRID ###############################
def realdebrid():
	try:
		authorize = xbmcaddon.Addon("script.module.authorize.android") #from
		debrid = xbmcaddon.Addon("script.realdebrid") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		debrid.setSetting("rd_access", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		debrid.setSetting("rd_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		debrid.setSetting("rd_refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		debrid.setSetting("rd_secret", secret) #to setting
		ezra()
	except:
		ezra()
	################## COPY TO EZRA ###############################		
def ezra():
	try:
		ezra = xbmcaddon.Addon("plugin.video.ezra")
		download = ("var/media/KODI/")
		ezra.setSetting("movie_download_directory", download) #to setting	
		ezra.setSetting("tvshow_download_directory", download) #to setting	
		ezra.setSetting("premium_download_directory", download) #to setting		
		reboot()
	except:
		reboot()
	############################ RESYNC FEN AND REBOOT ###################################################
def kill():
		os._exit(1)

def reboot():
		time.sleep(1)
		xbmc.executebuiltin("ActivateWindow(10025,plugin://script.module.fenomscrapers/?action=syncMyAccount)")
		time.sleep(1)
		dialog = xbmcgui.Dialog()
		dialog.notification('SYNC', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(1)
		kill()
	
	
	
if __name__ == "__main__":
	main()

