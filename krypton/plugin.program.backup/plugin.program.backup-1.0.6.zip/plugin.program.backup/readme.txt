TO USE THE ADDON ENTER THE ADDON SETTINGS AND NAVIGATE TO WHERE YOU WANT THE FILES TO BE BACKED UP TO.

THE SERVICE SCRIPT WILL RUN EVERY BOOT BACKING UP THE CODED PLUGINS.

TO RESTORE DATA CLICK THE RESTORE ADDON AND IT WILL START THEN REBOOT.

CAN CODE IN WIFI SETTINGS AS WELL.

ADD OR REMOVE PLUGINS FROM THE service.py

plugin.video.kemo
plugin.video.shadow
plugin.video.seren
plugin.video.themoviedb.helper
script.module.myaccounts
script.module.resolveurl
script.plex
script.realdebrid
script.trakt
service.coreelec.settings
