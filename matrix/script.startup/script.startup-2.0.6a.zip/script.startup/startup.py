# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time
import xbmc, sys
import requests


def MYIP(url='https://api.ipify.org/'):
	ip = requests.get(url).content
	dialog = xbmcgui.Dialog()
	xbmc.executebuiltin('RunScript(special://home/addons/script.startup/resources/scripts/skinupdate.py)')
	dialog.notification('[COLOR lime][B]MATRIX CoreELEC[/B][/COLOR]', 'Welcome to Kodi', xbmcgui.NOTIFICATION_INFO, 10000)
	time.sleep(20)	

	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "script.logviewer","enabled":true}}') 



	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/packages/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/temp/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	dialog = xbmcgui.Dialog()
	dialog.notification('Addon Cleaner', 'Addons and packages purged.', xbmcgui.NOTIFICATION_INFO, 5000)

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin( 'RunScript(plugin.video.themoviedb.helper, update_players)' )

try:	
	MYIP()
except:
    #pass
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "script.logviewer","enabled":false}}') 

	dialog=xbmcgui.Dialog()
	dialog.ok('NOT CONNECTED TO WIFI',"[B][COLOR purple]NO INTERNET DETECTED PLEASE CONNECT[/COLOR][/B]")
	xbmcgui.Dialog().ok('CoreELEC SETTINGS', 'Scroll to Connections and select your WiFi. Addon will open once you click OK')
	xbmc.executebuiltin('RunAddon(service.coreelec.settings)')