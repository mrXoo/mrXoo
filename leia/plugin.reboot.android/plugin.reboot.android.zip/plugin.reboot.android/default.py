import os


def flawless():
		xbmc.executebuiltin('System.ExecWait(/usr/sbin/rebootfromnand)')
		xbmc.executebuiltin('Reboot')
flawless()
