import urllib
from sanitize_filename import sanitize
import xbmc
import xbmcgui
from urllib.parse import urljoin,quote,unquote,urlparse,parse_qsl
import json

def log(x):
    xbmc.log(repr(x), xbmc.LOGERROR)


label = xbmc.getInfoLabel('ListItem.Label')
url = xbmc.getInfoLabel('ListItem.FileNameAndPath ')
if not url.startswith('http'):
    try:
        parse = urlparse(url)
        #log(parse)
        qs = parse_qsl(parse.query)
        #log(qs)
        qs = dict(qs)
        #log(qs)
        url = qs.get('url')
        #log(url)    
    except:
        pass
        
#log((label,url))
if url:
    cmd = f"RunPlugin(plugin://plugin.video.downloader/add_item/{quote(url, safe='')}/{quote(label, safe='')})"
    result = xbmc.executebuiltin(cmd)

