# script.realdebrid

Unofficial RealDebrid client. Manage your torrents, unrestricted links and view host statuses all within Kodi

Taken from https://github.com/ptom98/PTOM/tree/master/script.realdebrid

Corrections and additions
Works also on Kodi 19 (Matrix)

# Installation in kodi:
Via repository https://peno64.github.io/repository.peno64/
