from time import *             #meaning from time import EVERYTHING


ONE_DAY = 24 * 60 * 60  # seconds
DELAY = 2 * 60  # seconds


start_time = time()

current_time = start_time
while current_time <= start_time + ONE_DAY - DELAY:
################################# THIS RUNS EVERY TIME AT STARTUP ################################
################################# ADD LINE FOR EACH ADDON TO INSTALL ################################

    xbmc.executebuiltin('InstallAddon(script.module.cocoscrapers)')
    xbmc.executebuiltin('InstallAddon(plugin.video.umbrella)')
    # sleep(120)
    # xbmc.executebuiltin('RunScript(special://home/addons/script.kodi.settings/resources/repoaddonauth.py)')	
	

	
	
	
	
	
    sleep(DELAY)
    current_time = time()