# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
import xbmc
import os

xbmc.log(repr(sys.argv))


def main():
	seren()


	################## COPY TO SEREN ###############################
def seren():
	try:
		seren = xbmcaddon.Addon("plugin.video.seren")
		download = ("var/media/KODI/")
		seren.setSetting("download.location", download) #to setting		
		ezra()
	except:
		ezra()
	################## COPY TO EZRA ###############################		
def ezra():
	try:
		ezra = xbmcaddon.Addon("plugin.video.ezra")
		download = ("var/media/KODI/")
		true = ("true")
		quality = ("SD, 720p, 1080p")
		#ezra.setSetting("movie_download_directory", download) #to setting	
		#ezra.setSetting("tvshow_download_directory", download) #to setting	
		#ezra.setSetting("premium_download_directory", download) #to setting	
		ezra.setSetting("auto_play_movie", true) #to setting	
		ezra.setSetting("autoplay_quality_movie", quality) #to setting	
		ezra.setSetting("results_quality_movie", quality) #to setting	
		ezra.setSetting("auto_play_episode", true) #to setting	
		ezra.setSetting("autoplay_quality_episode", quality) #to setting
		ezra.setSetting("results_quality_episode", quality) #to setting		
		ezra.setSetting("autoplay_next_episode", true) #to setting	
		ezra.setSetting("autoplay_next_show_window", true) #to setting		

		shadow()
	except:
		shadow()
		
	################## COPY TO SHADOW ###############################
def shadow():
	try:
		shadow = xbmcaddon.Addon("plugin.video.shadow")
		true = ("true")
		shadow.setSetting("debrid_use", true) #to setting
		tmdb()
	except:
		tmdb()

	################## COPY TO TMDB ###############################
def tmdb():
	try:
		tmdb = xbmcaddon.Addon("plugin.video.themoviedb.helper")
		false = ("false")
		tmdb.setSetting("combined_players", false) #to setting
		end()
	except:
		end()


def end():
		time.sleep(1)



	
if __name__ == "__main__":
	main()