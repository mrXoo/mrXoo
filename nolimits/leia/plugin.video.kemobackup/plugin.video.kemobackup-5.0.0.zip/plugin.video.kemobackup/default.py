 #############Imports#############
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,base64,os,re,unicodedata,requests,time,string,sys,urllib,urllib2,json,urlparse,datetime,zipfile,shutil
from resources.modules import client,control,tools,shortlinks
from datetime import date
import xml.etree.ElementTree as ElementTree

import time

#################################

#############Defined Strings#############
addon_id     = 'plugin.video.kemobackup'
selfAddon    = xbmcaddon.Addon(id=addon_id)
icon         = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))

accounticon  = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'account.png'))
livetvicon	 = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'livetv.png'))
catchupicon	 = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'catchup.png'))
vodicon	     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'vod.png')) 
seriesicon   = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'tv.png'))
settingsicon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'settings.png'))
logouticon	 = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'logout.png'))
searchicon   = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'search.png'))
currenticon  = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'current.png'))
allowedicon  = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'allowed.png'))
usericon     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'user.png'))
passicon    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'pass.png'))
cacheicon    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'clear.png'))
advancedicon      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'eas.png'))
speedicon    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'speed.png'))
dataicon     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'meta.png'))
xxxicon      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'xxx.png'))
dateicon     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'date.png'))
statusicon      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'status.png'))

host		= base64.b64decode('aHR0cDovL21sc2gxLmNvbQ==').decode('utf-8')
port		= base64.b64decode('MjA4Ng==').decode('utf-8')
username     = base64.b64decode('Y2hhb3NtZWRpYQ==').decode('utf-8')
password     = base64.b64decode('MldxUUR6Mnh3SA==').decode('utf-8')

live_url     = '%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories'%(host,port,username,password)
vod_url      = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories'%(host,port,username,password)
series_url   = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories'%(host,port,username,password)
panel_api	 = '%s:%s/panel_api.php?username=%s&password=%s'%(host,port,username,password)
play_url     = '%s:%s/%s/%s/%s/'%(host,port,type,username,password)
all_series_url   = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series&cat_id=0'%(host,port,username,password)

Guide = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.kemobackup/resources/catchup', 'guide.xml'))
GuideLoc = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.kemobackup/resources/catchup', 'g'))

advanced_settings           =  xbmc.translatePath('special://home/addons/'+addon_id+'/resources/advanced_settings')
advanced_settings_target    =  xbmc.translatePath(os.path.join('special://home/userdata','advancedsettings.xml'))


#########################################
            
def home():
	tools.addDir('[B][COLOR white]Live[/COLOR][/B]','live',1,icon,fanart,'')
	tools.addDir('[B][COLOR white]Movies[/COLOR][/B]','vod',3,icon,fanart,'')
	tools.addDir('[B][COLOR white]TV Shows[/COLOR][/B]',series_url,24,seriesicon,fanart,'')
	tools.addDir('[B][COLOR white]Setup Guide[/COLOR][/B]','url',110,icon,fanart,'')
	
	
def livecategory(url):
	#tools.addDir('[B][COLOR white]Setup TV Guide[/COLOR][/B]','url',110,icon,fanart,'')
	tools.addDir('[B][COLOR white]Search Live Channels[/COLOR][/B]','url',49,searchicon,fanart,'')
	
	open = tools.OPEN_URL(live_url)
	all_cats = tools.regex_get_all(open,'<channel>','</channel>')
	for a in all_cats:
		name = tools.regex_from_to(a,'<title>','</title>')
		name = base64.b64decode(name)
		url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
		if xbmcaddon.Addon().getSetting('hidexxx')=='true':
			tools.addDir('%s'%name,url1,2,icon,fanart,'')
		else:
			if not 'XXX' in name:
				if not 'Adult' in name:
					tools.addDir('%s'%name,url1,2,icon,fanart,'')

def livelist(url):
	open = tools.OPEN_URL(url)
	all_cats = tools.regex_get_all(open,'<channel>','</channel>')
	for a in all_cats:
		name = tools.regex_from_to(a,'<title>','</title>')
		name = base64.b64decode(name)
		xbmc.log(str(name))
		try:
			name = re.sub('\[.*?min ','-',name)
		except:
			pass
		thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
		url1  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
		desc = tools.regex_from_to(a,'<description>','</description>')
		if xbmcaddon.Addon().getSetting('hidexxx')=='true':
			tools.addDir(name,url1,4,thumb,fanart,base64.b64decode(desc))
		else:
			if not 'XXX' in name:
				if not 'Adult' in name:
					tools.addDir(name,url1,4,thumb,fanart,base64.b64decode(desc))

def vod(url):

	tools.addDir('[B][COLOR orange]Search Movies[/COLOR][/B]','url',49,searchicon,fanart,'')

	if url =="vod":
		open = tools.OPEN_URL(vod_url)
	else:
		open = tools.OPEN_URL(url)
	all_cats = tools.regex_get_all(open,'<channel>','</channel>')
	for a in all_cats:
		if '<playlist_url>' in open:
			name = tools.regex_from_to(a,'<title>','</title>')
			url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
			tools.addDir(str(base64.b64decode(name)).replace('?',''),url1,3,icon,fanart,'')
		else:
			if xbmcaddon.Addon().getSetting('meta') == 'true':
				try:
					name = tools.regex_from_to(a,'<title>','</title>')
					name = base64.b64decode(name)
					thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
					url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
					desc = tools.regex_from_to(a,'<description>','</description>')
					desc = base64.b64decode(desc)
					plot = tools.regex_from_to(desc,'PLOT:','\n')
					cast = tools.regex_from_to(desc,'CAST:','\n')
					ratin= tools.regex_from_to(desc,'RATING:','\n')
					year = tools.regex_from_to(desc,'RELEASEDATE:','\n').replace(' ','-')
					year = re.compile('-.*?-.*?-(.*?)-',re.DOTALL).findall(year)
					runt = tools.regex_from_to(desc,'DURATION_SECS:','\n')
					genre= tools.regex_from_to(desc,'GENRE:','\n')
					tools.addDirMeta(str(name).replace('[/COLOR].','.[/COLOR]'),url,4,thumb,fanart,plot,str(year).replace("['","").replace("']",""),str(cast).split(),ratin,runt,genre)
				except:pass
				xbmcplugin.setContent(int(sys.argv[1]), 'movies')
			else:
				name = tools.regex_from_to(a,'<title>','</title>')
				name = base64.b64decode(name)
				thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
				url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
				desc = tools.regex_from_to(a,'<description>','</description>')
				if xbmcaddon.Addon().getSetting('hidexxx')=='true':
					tools.addDir(name,url,4,thumb,fanart,base64.b64decode(desc))
				else:
					if not 'XXX' in name:
						if not 'Adult' in name:
							tools.addDir(name,url,4,thumb,fanart,base64.b64decode(desc))
	xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE)	
		
##########################################
def search_scat(url):
    text = searchdialog()
    if not text:
        xbmc.executebuiltin("XBMC.Notification([COLOR red][B]Search is Empty[/B][/COLOR],Aborting search,4000,"+icon+")")
        return
    return scat(url,text)

def scat(url,search=None):
    tools.addDir('[B][COLOR orange]Search TV Shows[/COLOR][/B]',all_series_url,2424,searchicon,fanart,'')
    #log(url)
    open = tools.OPEN_URL(url)
    #log(open)
    all_cats = tools.regex_get_all(open,'<channel>','</channel>')
    for a in all_cats:
        if '<playlist_url>' in open:
            name = tools.regex_from_to(a,'<title>','</title>')
            name = base64.b64decode(name)
            url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
            #log((search,name))
            if search == None or (search.lower() in name.lower()):
                tools.addDir(str(name).replace('?',''),url1,24,icon,fanart,'')
        else:
            if xbmcaddon.Addon().getSetting('meta') == 'true':
                try:
                    name = tools.regex_from_to(a,'<title>','</title>')
                    name = base64.b64decode(name)
                    thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                    url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                    desc = tools.regex_from_to(a,'<description>','</description>')
                    desc = base64.b64decode(desc)
                    plot = tools.regex_from_to(desc,'PLOT:','\n')
                    cast = tools.regex_from_to(desc,'CAST:','\n')
                    ratin= tools.regex_from_to(desc,'RATING:','\n')
                    year = tools.regex_from_to(desc,'RELEASEDATE:','\n').replace(' ','-')
                    year = re.compile('-.*?-.*?-(.*?)-',re.DOTALL).findall(year)
                    runt = tools.regex_from_to(desc,'DURATION_SECS:','\n')
                    genre= tools.regex_from_to(desc,'GENRE:','\n')
                    tools.addDirMeta(str(name).replace('[/COLOR].','.[/COLOR]'),url,4,thumb,fanart,plot,str(year).replace("['","").replace("']",""),str(cast).split(),ratin,runt,genre)
                except:pass
                xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
            else:
                name = tools.regex_from_to(a,'<title>','</title>')
                name = base64.b64decode(name)
                thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                desc = tools.regex_from_to(a,'<description>','</description>')
                tools.addDir(name,url,4,thumb,fanart,base64.b64decode(desc))
    xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE)

##########################################

def seasons(url):
    if url =="seasons":
        open = tools.OPEN_URL(seasons_url)
    else:
        open = tools.OPEN_URL(url)
    all_cats = tools.regex_get_all(open,'<channel>','</channel>')
    for a in all_cats:
        if '<playlist_url>' in open:
            name = tools.regex_from_to(a,'<title>','</title>')
            url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
            tools.addDir(str(base64.b64decode(name)).replace('?',''),url1,21,icon,fanart,'')
        else:
            if xbmcaddon.Addon().getSetting('meta') == 'true':
                try:
                    name = tools.regex_from_to(a,'<title>','</title>')
                    name = base64.b64decode(name)
                    thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                    url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                    desc = tools.regex_from_to(a,'<description>','</description>')
                    desc = base64.b64decode(desc)
                    plot = tools.regex_from_to(desc,'PLOT:','\n')
                    cast = tools.regex_from_to(desc,'CAST:','\n')
                    ratin= tools.regex_from_to(desc,'RATING:','\n')
                    year = tools.regex_from_to(desc,'RELEASEDATE:','\n').replace(' ','-')
                    year = re.compile('-.*?-.*?-(.*?)-',re.DOTALL).findall(year)
                    runt = tools.regex_from_to(desc,'DURATION_SECS:','\n')
                    genre= tools.regex_from_to(desc,'GENRE:','\n')
                    tools.addDirMeta(str(name).replace('[/COLOR].','.[/COLOR]'),url,4,thumb,fanart,plot,str(year).replace("['","").replace("']",""),str(cast).split(),ratin,runt,genre)
                except:pass
                xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
            else:
                name = tools.regex_from_to(a,'<title>','</title>')
                name = base64.b64decode(name)
                thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                desc = tools.regex_from_to(a,'<description>','</description>')
                tools.addDir(name,url,4,thumb,fanart,base64.b64decode(desc))
    xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE)



##########################################
def series(url):
    log(url)
    if url =="vod":
        open = tools.OPEN_URL(vod_url)
    else:
        open = tools.OPEN_URL(url)
    log(open)
    all_cats = tools.regex_get_all(open,'<channel>','</channel>')
    for a in all_cats:
        if '<playlist_url>' in open:
            name = tools.regex_from_to(a,'<title>','</title>')
            url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
            tools.addDir(str(base64.b64decode(name)).replace('?',''),url1,20,icon,fanart,'')
        else:
            if xbmcaddon.Addon().getSetting('meta') == 'true':
                try:
                    name = tools.regex_from_to(a,'<title>','</title>')
                    name = base64.b64decode(name)
                    thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                    url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                    desc = tools.regex_from_to(a,'<description>','</description>')
                    desc = base64.b64decode(desc)
                    plot = tools.regex_from_to(desc,'PLOT:','\n')
                    cast = tools.regex_from_to(desc,'CAST:','\n')
                    ratin= tools.regex_from_to(desc,'RATING:','\n')
                    year = tools.regex_from_to(desc,'RELEASEDATE:','\n').replace(' ','-')
                    year = re.compile('-.*?-.*?-(.*?)-',re.DOTALL).findall(year)
                    runt = tools.regex_from_to(desc,'DURATION_SECS:','\n')
                    genre= tools.regex_from_to(desc,'GENRE:','\n')
                    tools.addDirMeta(str(name).replace('[/COLOR].','.[/COLOR]'),url,4,thumb,fanart,plot,str(year).replace("['","").replace("']",""),str(cast).split(),ratin,runt,genre)
                except:pass
                xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
            else:
                name = tools.regex_from_to(a,'<title>','</title>')
                name = base64.b64decode(name)
                thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                desc = tools.regex_from_to(a,'<description>','</description>')
                tools.addDir(name,url,4,thumb,fanart,base64.b64decode(desc))
    xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE)
		
#####################################################################

def stream_video(url):
	url = str(url).replace('USERNAME',username).replace('PASSWORD',password)
	liz = xbmcgui.ListItem('', iconImage='DefaultVideo.png', thumbnailImage=icon)
	liz.setInfo(type='Video', infoLabels={'Title': '', 'Plot': ''})
	liz.setProperty('IsPlayable','true')
	liz.setPath(str(url))
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	
	
def subm():
	tools.addDir('[COLOR white]Search Movies[/COLOR]','url',49,searchicon,fanart,'')
	tools.addDir('[COLOR white]Movie Categories[/COLOR]','vod',3,vodicon,fanart,'')
	#tools.addDir('[COLOR white]All Movies[/COLOR]','vod',333,vodicon,fanart,'')


def subt():
	tools.addDir('[COLOR white]Search TV Shows[/COLOR]',all_series_url,2424,searchicon,fanart,'')
	tools.addDir('[COLOR white]TV Show Categories[/COLOR]',series_url,24,seriesicon,fanart,'')


def searchdialog():
	search = control.inputDialog(heading='Search for a TV Show?')
	if search=="":
		return
	else:
		return search


	
def search_movies():
    if mode==([3, 4, 20, 21]):
        return False
    #text = searchdialog()
    text = xbmcgui.Dialog().input("Search")
    xbmc.log(repr(text),xbmc.LOGERROR)
    if not text:
        xbmc.executebuiltin("XBMC.Notification([COLOR blue][B]Search is Empty[/B][/COLOR],Aborting search,4000,"+icon+")")
        return
    xbmc.log(str(text))
    open = tools.OPEN_URL(panel_api)
    import json
    j = json.loads(open)
    available_channels = j["available_channels"]
    for id,channel in available_channels.items():
        name = channel["name"] or ''
        type = channel["stream_type"] or ''
        ext = channel["container_extension"] or ''
        thumb = channel["stream_icon"] or ''
        fanart = ''
        liz=xbmcgui.ListItem(name, iconImage=thumb, thumbnailImage=thumb)
        liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":'',})
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable","true")
        play_url     = '%s:%s/%s/%s/%s/'%(host,port,type,username,password)
        xbmc.log(repr(name))
        if text in name.lower():
            #tools.addDir(name,play_url+id+'.'+ext,4,thumb,fanart,'')
            play_url     = '%s:%s/%s/%s/%s/'%(host,port,type,username,password)
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=play_url+id+'.'+ext,listitem=liz,isFolder=False)
        elif text not in name.lower() and text in name:
            #tools.addDir(name,play_url+id+'.'+ext,4,thumb,fanart,'')
            play_url     = '%s:%s/%s/%s/%s/'%(host,port,type,username,password)
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=play_url+id+'.'+ext,listitem=liz,isFolder=False)
    xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE)
	

	
def all_movies():
	open = tools.OPEN_URL(panel_api)
	import json
	j = json.loads(open)
	available_channels = j["available_channels"]
	for id,channel in available_channels.items():
		name = channel["name"] or ''
		type = channel["stream_type"] or ''
		ext = channel["container_extension"] or ''
		thumb = channel["stream_icon"] or ''
		fanart = ''
		liz=xbmcgui.ListItem(name, iconImage=thumb, thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":'',})
		liz.setProperty('fanart_image', fanart)
		liz.setProperty("IsPlayable","true")
		play_url	 = '%s:%s/%s/%s/%s/'%(host,port,type,username,password)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=play_url+id+'.'+ext,listitem=liz,isFolder=False)
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)

		
def accountinfo():
	open = tools.OPEN_URL(panel_api)
	try:
		username   = tools.regex_from_to(open,'"username":"','"')
		password   = tools.regex_from_to(open,'"password":"','"')
		status     = tools.regex_from_to(open,'"status":"','"')
		connects   = tools.regex_from_to(open,'"max_connections":"','"')
		active     = tools.regex_from_to(open,'"active_cons":"','"')
		expiry     = tools.regex_from_to(open,'"exp_date":"','"')
		expiry     = datetime.datetime.fromtimestamp(int(expiry)).strftime('%d/%m/%Y - %H:%M')
		expreg     = re.compile('^(.*?)/(.*?)/(.*?)$',re.DOTALL).findall(expiry)
		for day,month,year in expreg:
			month     = tools.MonthNumToName(month)
			year      = re.sub(' -.*?$','',year)
			expiry    = month+' '+day+' - '+year
			tools.addDir('[B][COLOR blue]Account Status :[/COLOR][/B] %s'%status,'','',statusicon,fanart,'')
			tools.addDir('[B][COLOR blue]Expiry Date:[/COLOR][/B] '+expiry,'','',dateicon,fanart,'')
			tools.addDir('[B][COLOR blue]Username :[/COLOR][/B] '+username,'','',usericon,fanart,'')
			tools.addDir('[B][COLOR blue]Password :[/COLOR][/B] '+password,'','',passicon,fanart,'')
			tools.addDir('[B][COLOR blue]Allowed Connections:[/COLOR][/B] '+connects,'','',allowedicon,fanart,'')
			tools.addDir('[B][COLOR blue]Current Connections:[/COLOR][/B] '+ active,'','',currenticon,fanart,'')
	except:pass
		

def livesection():
	tools.addDir('[COLOR white]Live TV Channel Groups[/COLOR]','live',1,icon,fanart,'')
	tools.addDir('[COLOR white]Live TV Channel Search[/COLOR]','url',5,icon,fanart,'')

def kill():
		os._exit(1)
		
def remove():
	removetv = xbmc.translatePath('special://home/userdata/Database/TV32.db')
	removeepg = xbmc.translatePath('special://home/userdata/Database/Epg12.db')	
	os.remove(removetv)
	os.remove(removeepg)
	xbmc.sleep(500)
	kill() 

def pvrsetup():
	choice = xbmcgui.Dialog().yesno('EPG SETUP', 'Would you like the full TV guide (SLOWER) or would you like the most popular catagories from USA, CANADA & UK?', nolabel='POPULAR',yeslabel='FULL', autoclose=int(20000))
	if choice == 0: #NO LABEL popular
		correctPVR()
		return 

	elif choice == 1: # YES LABEL full
		correctPVRfull()
		return 

def correctPVR():

	addon = xbmcaddon.Addon('plugin.video.kemobackup')
	username     = base64.b64decode('Y2hhb3NtZWRpYQ==').decode('utf-8')
	password     = base64.b64decode('MldxUUR6Mnh3SA==').decode('utf-8')
	jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'
	IPTVon 	   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
	nulldemo   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
	loginurl   = '%s:%s/get.php?username=%s&password=%s&type=m3u_plus&output=mpegts' %(host,port,username,password)
	#loginurl   = '%s:%s/streams/hls/%s' %(host,port,password)
	EPGurl     = '%s:%s/xmltv.php?username=%s&password=%s' %(host,port,username,password)
	#EPGurl     = '%s:%s/guide/%s/guide.xml' %(host,port,password)
	GroupsFile = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.kemobackup/resources/customTVGroups.xml'))
	removetv = xbmc.translatePath('special://home/userdata/Database/TV38.db')
	removeepg = xbmc.translatePath('special://home/userdata/Database/Epg13.db')

	xbmc.executeJSONRPC(jsonSetPVR)
	xbmc.executeJSONRPC(IPTVon)
	xbmc.executeJSONRPC(nulldemo)
	
	moist = xbmcaddon.Addon('pvr.iptvsimple')
	moist.setSetting(id='m3uUrl', value="https://www.dropbox.com/s/s45l5l2in9vwb57/iptv.m3u8?dl=1")
	moist.setSetting(id='epgUrl', value=EPGurl)
	moist.setSetting(id='m3uCache', value="true")
	moist.setSetting(id='epgCache', value="true")
	#moist.setSetting(id='m3uPath', value="")
	moist.setSetting(id='m3uPathType', value="1")		
	xbmc.executebuiltin("Container.Refresh")
	try:
		remove()
	except:
		kill()    
 

def correctPVRfull():

	addon = xbmcaddon.Addon('plugin.video.kemobackup')
	username     = base64.b64decode('Y2hhb3NtZWRpYQ==').decode('utf-8')
	password     = base64.b64decode('MldxUUR6Mnh3SA==').decode('utf-8')
	jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'
	IPTVon 	   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
	nulldemo   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
	loginurl   = '%s:%s/get.php?username=%s&password=%s&type=m3u_plus&output=mpegts' %(host,port,username,password)
	#loginurl   = '%s:%s/streams/hls/%s' %(host,port,password)
	EPGurl     = '%s:%s/xmltv.php?username=%s&password=%s' %(host,port,username,password)
	#EPGurl     = '%s:%s/guide/%s/guide.xml' %(host,port,password)
	GroupsFile = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.kemobackup/resources/customTVGroups.xml'))
	removetv = xbmc.translatePath('special://home/userdata/Database/TV38.db')
	removeepg = xbmc.translatePath('special://home/userdata/Database/Epg13.db')

	xbmc.executeJSONRPC(jsonSetPVR)
	xbmc.executeJSONRPC(IPTVon)
	xbmc.executeJSONRPC(nulldemo)
	
	moist = xbmcaddon.Addon('pvr.iptvsimple')
	moist.setSetting(id='m3uUrl', value="https://www.dropbox.com/s/w5etl9xneyyvqop/iptv.m3u8?dl=1")
	moist.setSetting(id='epgUrl', value=EPGurl)
	moist.setSetting(id='m3uCache', value="true")
	moist.setSetting(id='epgCache', value="true")
	#moist.setSetting(id='m3uPath', value="")
	moist.setSetting(id='m3uPathType', value="1")	
	try:
		remove()
	except:
		kill()  

    
params=tools.get_params()
url=None
name=None
mode=None
iconimage=None
description=None
query=None
type=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass
try:
	query=urllib.unquote_plus(params["query"])
except:
	pass
try:
	type=urllib.unquote_plus(params["type"])
except:
	pass

if mode==None or url==None or len(url)<1:
	home()


elif mode==1:
	livecategory(url)

elif mode==2:
	livelist(url)

elif mode==3:
	vod(url)
    
elif mode==333:
	all_movies()
    
elif mode==4:
	stream_video(url)

elif mode==5:
	search_tv()

elif mode==49:
	search_movies()

elif mode==6:
	accountinfo()

elif mode==9:
	xbmc.executebuiltin('ActivateWindow(busydialog)')
	tools.Trailer().play(url) 
	xbmc.executebuiltin('Dialog.Close(busydialog)')

elif mode==10:
	addonsettings(url,description)
    
elif mode==11:
	subm()

elif mode==12:
	subt()

elif mode==13:
	catchup()

elif mode==14:
	tvarchive(name,description)
	
elif mode==15:
	listcatchup2()
	
elif mode==16:
	extras()
	
elif mode==160:
	livetools()

elif mode==17:
	shortlinks.Get()

elif mode==19:
	get()

elif mode==20:
	series(url)

elif mode==21:
	seasons(url)

# elif mode==22:
	# eps(url)

elif mode==23:
	get_settings()

elif mode==24:
	scat(url)

elif mode==2424:
    search_scat(url)
    
elif mode==1616:
	livesection()
    
elif mode==210:
	get_settings()
    
elif mode==200:
	channelgroups(url,description)
    
elif mode==110:
	pvrsetup()
    
elif mode==111:
	deletem3u()
    
elif mode==2222:
	use_file()
    
elif mode==220:
	start()
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
