# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)


def copytree(src, dst):
    names = os.listdir(src)

    try:os.makedirs(dst)
    except:pass

    for name in names:
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)
        try:
            if os.path.isdir(srcname):
                copytree(srcname, dstname)
            else:
                shutil.copy(srcname, dstname)
        except Exception as e:
            print (e)

		################# SERVICE XML      BACKUP      ##########################

def backup ():

        slash   = ('/')	
        drive	= xbmcaddon.Addon().getSetting('Drive')
        usb = ('/KODI/')
        database_folder  = xbmc.translatePath('special://home/userdata/Database')	
        source_folder = xbmc.translatePath('special://home/userdata/addon_data/')
        movies = xbmc.translatePath('/plugin.video.themoviedb.helper/movies')
        tvshows = xbmc.translatePath('plugin.video.themoviedb.helper/tvshows')
        #source_network = ('C:/Users/ED/Documents/')
        source_network = ('/storage/.cache/connman/')		
        connman = ('/connman/')
        kodi = ('/.kodi/')
        addons  = ('/addons/')
        userdata = ('/userdata/')
        addon_data = ('/addon_data/')
        database = ('Database/')
        addon_folder = xbmc.translatePath('special://home/addons/')	
        storage = ('storage/')
        cache = ('.cache/')
        media = ('/media/')        
		
        time.sleep(3600)	

			
################################ MAKE ALL DIRS ON MEDIA ############################################################

		
        if not os.path.exists(media + storage + cache + connman):  
            os.makedirs(media + storage + cache + connman)        

        if not os.path.exists(media + storage + kodi + addons):  
            os.makedirs(media + storage + kodi + addons)         


        if not os.path.exists(media + storage + kodi + userdata + database):  
            os.makedirs(media + storage + kodi + userdata + database)         


        if not os.path.exists(media + storage + kodi + userdata + addon_data):  
            os.makedirs(media + storage + kodi + userdata + addon_data) 

# #################### MAKE FOLDERS ON USB #########################################

        if not os.path.exists(drive + storage):  
            os.makedirs(drive + storage) 
		
# ############################### COPY CONNMAN WIFI SETTINGS TO FOLDER /media/connman #######################
 	
        from distutils.dir_util import copy_tree
        copy_tree(source_network, media + storage + cache + connman)
		
		
# ###################  COPY ADDONS TO media/.kodi/addons #############################################################			

        addon = "plugin.video.kemo"
        from distutils.dir_util import copy_tree
        copy_tree(addon_folder + addon, media + storage + kodi + addons + addon)


		
############################# COPY ADDONS DB FILES TO /media/.kodi/userdata/Database  #############################################
        xbmcvfs.copy('special://home/userdata/Database/MyVideos107.db',media + storage + kodi + userdata + database + 'MyVideos107.db')
        xbmcvfs.copy('special://home/userdata/Database/MyVideos116.db',media + storage + kodi + userdata + database + 'MyVideos116.db')
        xbmcvfs.copy('special://home/userdata/Database/MyVideos119.db',media + storage + kodi + userdata + database + 'MyVideos119.db')
        xbmcvfs.copy('special://home/userdata/Database/ViewModes6.db',media + storage + kodi + userdata + database + 'ViewModes6.db')
        #xbmcvfs.copy('special://home/userdata/Database/Addons27.db',media + storage + kodi + userdata + database + 'Addons27.db')
        #xbmcvfs.copy('special://home/userdata/Database/Addons33.db',media + storage + kodi + userdata + database + 'Addons33.db')
        xbmcvfs.copy('special://home/userdata/favorites.xml',media + storage + kodi + userdata + 'favourites.xml')				
        xbmcvfs.copy('special://home/userdata/sources.xml',media + storage + kodi + userdata + 'sources.xml')

		
	############################### COPY ADDON_DATA TO media/storage/.kodi ###################
	
	####################################################### COPY THE SECTION BELOW TO ADD PLUGINS #################################

        addon = "script.plex"
# fetch all files
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):
    # construct full file path
            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name
    # copy only files
            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
	#####################################################################################################################
        addon = "plugin.video.themoviedb.helper"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)



        from distutils.dir_util import copy_tree
        copy_tree(source_folder + movies, media + storage + kodi + userdata + addon_data + movies)

        from distutils.dir_util import copy_tree
        copy_tree(source_folder + tvshows, media + storage + kodi + userdata + addon_data + tvshows)	
		
			
        addon = "plugin.video.kemo"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				


        addon = "plugin.video.shadow"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
				
				
        addon = "plugin.video.seren"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				

				
        addon = "script.module.myaccounts"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				

				
        addon = "script.module.resolveurl"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
				
        addon = "script.realdebrid"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				


				
        addon = "script.trakt"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				

				
        addon = "service.coreelec.settings"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				

        addon = "plugin.program.backup"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)

                
 				
        addon = "pvr.iptvsimple"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
                 
				
        addon = "plugin.program.iptv.groups"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)               
 
 
        addon = "plugin.video.realizer"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
                
 
        addon = "plugin.video.realizerx"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = media + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
			
            
        addon = "plugin.video.foxystreams"
        if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
            os.makedirs(media + storage + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + storage + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
	
# #################### COPY THE STORAGE FOLDER FROM MEDIA TO THE  USB #########################################  
  
        from distutils.dir_util import copy_tree
        copy_tree(media + storage , drive + storage)
	
        
        time.sleep(60)

while True: backup()
