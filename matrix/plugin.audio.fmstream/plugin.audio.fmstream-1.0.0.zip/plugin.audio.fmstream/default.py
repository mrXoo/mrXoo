from xbmcswift2 import Plugin
import xbmc,xbmcplugin,xbmcaddon,xbmcvfs,xbmcgui
import requests
import re
import sys
import json
import time


def log(v):
    xbmc.log(repr(v), xbmc.LOGERROR)

def addon_id():
    return xbmcaddon.Addon().getAddonInfo('id')

def get_icon_path(icon_name):
    if plugin.get_setting('user.icons') == "true":
        user_icon = "special://profile/addon_data/%s/icons/%s.png" % (addon_id(),icon_name)
        if xbmcvfs.exists(user_icon):
            return user_icon
    return "special://home/addons/%s/resources/img/%s.png" % (addon_id(),icon_name)


plugin = Plugin()


def fmstream(query):
    keya = 0x3ee9;
    keyb = 0x21ff;
    key = round(keya * int(time.time()) + keyb);

    url = f"http://fmstream.org/index.php?hq=1&{query}&key={key:x}";
    if plugin.get_setting('hq') == "true":
        url = f"{url}&hq=1"
    order = plugin.get_setting('order')
    if order == "Big":
        url = f"{url}&o=big"
    elif order == "Medium":
        url = f"{url}&o=med"
    elif order == "Small":
        url = f"{url}&o=sma"        
    t = requests.get(url).text
    t = t.splitlines()[3:]
    j = json.loads(t[0])
    data = j["data"]
    return data


@plugin.route('/fmstream_urls/<query>/<id>')
def fmstream_urls(query,id):
    data = fmstream(query)
    station = [x for x in data if x['id'] == id][0]
    items = []
    for url in station["urls"]:
        items.append(
        {
            'label': f'{station["program"]} - {url["br"]}kbps {url["sr"]}khz - {url["url"]}',
            'path': url["url"], 
            'thumbnail': get_icon_path('radio'),
            'info_type': 'Audio',
            'info':{"mediatype": "audio"},
            'is_playable': True,            
        })
    return items

    
@plugin.route('/stations/<key>/<value>')    
def stations(key,value):
    query = f"{key}={value}"
    data = fmstream(query)
    items = []
    for station in data:
        program = station["program"]
        id = station["id"]
        items.append(
        {
            'label': f"{program}",
            'path': plugin.url_for(fmstream_urls, query=query, id=id),
            'thumbnail': get_icon_path('radio'),
        })
    return items


@plugin.route('/countries')
def countries():
    html = requests.get("http://fmstream.org/country.htm").text
    found = re.findall(r'<a href="(.*?)".*?>(.*?)</a',html)
    items = []
    for match in found:
        query = re.search(r'c=(.*?)&', match[0])
        if query:
            code = query.group(1)
            name = match[1]
            items.append(
            {
                'label': name,
                'path': plugin.url_for(stations, key="c", value=code),
                'thumbnail': f"http://fmstream.org/flagsitu/{code}.gif",
            })
    return items
 
    
@plugin.route('/languages')
def languages():
    html = requests.get("http://fmstream.org/language.htm").text
    found = re.findall(r'<a href="(.*?)".*?>(.*?)</a',html)
    items = []
    for match in found:
        query = re.search(r'l=(.*?)&', match[0])
        if query:
            code = query.group(1)
            name = match[1]
            items.append(
            {
                'label': name,
                'path': plugin.url_for(stations, key="l", value=code),
                'thumbnail': get_icon_path('genre_talk'),
            })
    return items       
  
    
@plugin.route('/styles')
def styles():
    html = requests.get("http://fmstream.org/style.htm").text
    found = re.findall(r'<a href="(.*?)".*?>(.*?)</a',html)
    items = []
    for match in found:
        query = re.search(r'style=(.*?)&', match[0])
        if query:
            code = query.group(1)
            name = match[1]
            items.append(
            {
                'label': name,
                'path': plugin.url_for(stations, key="style", value=code),
                'thumbnail': get_icon_path('genre_music'),
            })
    return items       


@plugin.route('/search/<code>')    
def search(code):
    query = f"s={code}"
    data = fmstream(query)
    items = []
    for station in data:
        program = station["program"]
        id = station["id"]
        items.append(
        {
            'label': program,
            'path': plugin.url_for(fmstream_urls, query=query, id=id),
            'thumbnail': get_icon_path('search'),
        })
    return items
  
  

@plugin.route('/search_dialog')
def search_dialog():
    d = xbmcgui.Dialog()
    what = d.input("Search")
    if what:
        return search(what)




@plugin.route('/')
def index():
    items = []

    items.append(
    {
        'label': "Countries",
        'path': plugin.url_for(countries),
        'thumbnail': get_icon_path('genre_foreign'),
    })
    items.append(
    {
        'label': "Languages",
        'path': plugin.url_for(languages),
        'thumbnail': get_icon_path('genre_talk'),
    })  
    items.append(
    {
        'label': "Styles",
        'path': plugin.url_for(styles),
        'thumbnail': get_icon_path('genre_music'),
    })      
    items.append(
    {
        'label': "Search",
        'path': plugin.url_for(search_dialog),
        'thumbnail': get_icon_path('search'),
    })

    return items



if __name__ == '__main__':
    plugin.run()
