# -*- coding: utf-8 -*-


import xbmcgui

DIALOG = xbmcgui.Dialog()

if __name__ == "__main__":
    response = DIALOG.yesno('WOULD YOU LIKE THE MOVIE & TV COVERS?', '', yeslabel='YES', nolabel='NO')

    if response:
        #YES
        response = DIALOG.yesno('WHAT WOULD YOU LIKE TO WATCH TODAY?', '', yeslabel='TVSHOWS', nolabel='MOVIES')

        if response:
        #TV SHOWS
            xbmc.executebuiltin( 'RunPlugin(plugin://plugin.video.openmeta/update_players)' )
            xbmc.executebuiltin("RunPlugin(plugin://script.extendedinfo/?info=alltvshows)")

        else:
        #MOVIES
            xbmc.executebuiltin( 'RunPlugin(plugin://plugin.video.openmeta/update_players)' )
            xbmc.executebuiltin("RunPlugin(plugin://script.extendedinfo/?info=allmovies)")

