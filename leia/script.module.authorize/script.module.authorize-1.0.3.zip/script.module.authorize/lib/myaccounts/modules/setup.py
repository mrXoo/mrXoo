#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs, os
import time
#dialog = xbmcgui.Dialog()
#dialog.ok("WELCOME TO FIRST RUN", "Once you have authorized Trakt you will need to click the SYNC addon. NOTE!!! The setup addon called SYNC Can be found under the puzzle piece then programs") 
xbmc.executebuiltin('RunScript(script.trakt, action=auth_info)')
xbmcvfs.copy('special://home/addons/script.module.authorize/lib/myaccounts/modules/MyVideos116.db','special://home/userdata/Database/MyVideos116.db')
time.sleep(60)

xbmc.executebuiltin('RunAddon(script.module.authorize)')
