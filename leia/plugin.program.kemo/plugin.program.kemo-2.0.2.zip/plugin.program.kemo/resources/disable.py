# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import sys
import os
import xbmc, xbmcgui, xbmcvfs
import time, datetime


removesettings = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groups/settings.xml')	
removem3u = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groups/iptv.m3u8')	
removesettingsfull = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groupsfull/settings.xml')	
removem3ufull = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groupsfull/iptv.m3u8')	

def half():
	try:
		os.remove(removem3u)
		os.remove(removesettings)
	except:
		pass
	
def full():
	try:
		os.remove(removem3ufull)
		os.remove(removesettingsfull)
	except:
		pass




TARGETFOLDER = xbmc.translatePath( 
	'special://home/userdata/addon_data/pvr.iptvsimple/'
	)

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
	'special://home/userdata/addon_data/plugin.video.kemo/'
	)

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)
	

half()
full()		


xbmc.sleep(200)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":false}}') 
xbmc.executebuiltin('Dialog.Close(busydialog)')
xbmc.executebuiltin("Reboot") 