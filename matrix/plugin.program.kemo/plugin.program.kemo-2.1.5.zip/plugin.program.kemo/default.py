# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import sys
import os
import xbmc, xbmcgui, xbmcvfs
import time, datetime



def ENABLEADDONPROMPT():	
	choice = xbmcgui.Dialog().yesno('PVR INSTALL', 'Do you want to use the PVR for KEMO IPTV? !!!NOTE!!! Once setup reach out to the FB group for instructions', nolabel='YES',yeslabel='NO')
	if choice == 1:
		ENABLEADDON()

	elif choice == 0: 
		ENABLEADDONPVR()




def ENABLEADDON():	
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":true}}')
	#xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemobackup","enabled":true}}') 	
	xbmc.sleep(200)
	
	xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/start.py)')
	
def ENABLEADDONPVR():	
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":true}}')
	xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/pvr.py)')

	       
def DISABLEADDON():

	file = 'settings.xml'
	location = xbmc.translatePath('special://home/userdata/addon_data/pvr.iptvsimple/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)
		
	file = 'settings.xml'
	location = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.kemo/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)
		
	xbmc.sleep(200)
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":false}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":false}}') 
	#xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemobackup","enabled":false}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.iptv.recorder","enabled":false}}') 
	xbmc.executebuiltin('Dialog.Close(busydialog)')
			

##########################################################################################################################################
choice = xbmcgui.Dialog().yesno('KEMO INSTALL', 'Do you have a username and password for KEMO IPTV? !!!NOTE!!! Click NO to uninstall KEMO IPTV', nolabel='YES',yeslabel='NO')
if choice == 1:
	DISABLEADDON()

elif choice == 0: 
	ENABLEADDONPROMPT()