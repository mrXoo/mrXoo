# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import sys
import os
import xbmc, xbmcgui, xbmcvfs
import time, datetime








def ENABLEADDON():	
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemobackup","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.program.iptv.groupsfull","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.program.iptv.groups","enabled":true}}') 
	xbmc.sleep(200)
	xbmc.executebuiltin('Dialog.Close(busydialog)')	
	xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/start.py)')
	       
def DISABLEADDON():
	xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/disable.py)')
			

##########################################################################################################################################
# choice = xbmcgui.Dialog().yesno('KEMO INSTALL', 'Do you have a username and password for KEMO IPTV? !!!NOTE!!! Click NO to uninstall KEMO IPTV', nolabel='YES',yeslabel='NO')
# if choice == 1:
	# DISABLEADDON()

# elif choice == 0: 
	# ENABLEADDON()


msg = "[B][COLOR red]Do you have a username and password for KEMO IPTV? !!!NOTE!!! Click NO to uninstall KEMO IPTV[/COLOR][/B]"
dialog = xbmcgui.Dialog()
ret = dialog.yesno('INSTALL KEMO IPTV', msg)
if ret == True:
	ENABLEADDON()
else:
	DISABLEADDON()

	
# if __name__ == "__main__":
    # main()