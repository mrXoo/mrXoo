import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import datetime

from default import download_queue

def log(v):
    xbmc.log(repr(v), xbmc.LOGERROR)
 
  
monitor = xbmc.Monitor()

while not monitor.abortRequested():
    log("XXX")
    download_queue()
    #xbmc.executebuiltin('RunPlugin(plugin://plugin.video.downloader/download_queue)')
    xbmc.sleep(10000)
    log("YYY")

