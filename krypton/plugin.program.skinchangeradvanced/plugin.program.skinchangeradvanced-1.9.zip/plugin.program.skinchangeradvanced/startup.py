#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs

xbmc.sleep(2000)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.estuary"}}')
xbmc.executebuiltin('SendClick(11)')
xbmc.sleep(2000)
xbmcvfs.copy('special://home/addons/script.addon.importer.linux/stuff/userdata/addon_data/skin.xonfluence/settings.xml','special://profile/addon_data/skin.xonfluence/settings.xml')
xbmcvfs.copy('special://home/addons/script.addon.importer.android/stuff/userdata/addon_data/skin.xonfluence/settings.xml','special://profile/addon_data/skin.xonfluence/settings.xml')
xbmc.sleep(2000)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.xonfluence"}}')
xbmc.executebuiltin('SendClick(11)')

