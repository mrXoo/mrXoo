# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil
#import pathlib

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)


    
drive = xbmcaddon.Addon().getSetting('Drive')
media = xbmcaddon.Addon().getSetting('Card')
source_network = ('/storage/.cache/connman/')		
connman = ('/connman/')
kodi = ('/.kodi/')
addons  = ('/addons/')
userdata = ('/userdata/')
addon_data = ('/addon_data/')
database = ('Database/')
kodi_folder = ('/storage/.kodi/')
storage = ('/storage/')




def get_usb():
    src = (drive + storage)
    dst = (storage)
    from distutils.dir_util import copy_tree 

    if not os.path.exists(drive + storage + kodi + userdata):
        print ("File not exist")

    else:
        copy_tree(src,dst)
		
def get_media():
    src = (media + storage)
    dst = (storage)
    from distutils.dir_util import copy_tree 

    if not os.path.exists(media + storage + kodi + userdata):
        print ("File not exist")

    else:
        copy_tree(src,dst)


##########################################################################################################################

choice = xbmcgui.Dialog().yesno('SETTINGS RESTORE', 'Would you like to restore your personal settings now?', nolabel='NO',yeslabel='YES')
if choice == 0:
	xbmc.executebuiltin("Home")
elif choice == 1: 





############################### MATRIX ONLY #############################
# def countdown():
    # seconds = 10
    # percentage = 100
    # monitor = xbmc.Monitor()
    # pDialog = xbmcgui.DialogProgress()
    # pDialog.create("SETTINGS RESTORE")

    # while not monitor.abortRequested() and percentage > 0:
        # secondsTxt = "seconds" if seconds > 1 else "second"
        # pDialog.update(percentage, f"Settings will be restored in {seconds} {secondsTxt} Box will then reboot.")
        # seconds -= 1
        # percentage -= 10
        # if monitor.waitForAbort(1): break
        # if pDialog.iscanceled(): return True

# def main():
	# cancelled = countdown()

	# if cancelled:
		# return

		############################### 	DELETE DATABASE FILES FOR WHEN UPGRADING VERSIONS  #######################


	# file = 'MyVideos116.db'
	# location = xbmc.translatePath('special://home/userdata/Database/')
	# path = os.path.join(location, file)
	# if os.path.exists(path):
		# os.remove(path)


	# file = 'MyVideos119.db'
	# location = xbmc.translatePath('special://home/userdata/Database/')
	# path = os.path.join(location, file)
	# if os.path.exists(path):
		# os.remove(path)

	################################# RESTORE ALL KODI DATA ################################	


	get_usb()
	get_media()



	# ################################  DELETE INVOKER ADDON FOR NEW BUILD  ###################################

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/script.firstrun/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	xbmc.executebuiltin('Reboot')
	#xbmc.executebuiltin("Addon.OpenSettings(plugin.video.youtube)")



################################ MATRIX ONLY #################################	
# if __name__ == "__main__":
    # main()
