# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
import xbmc
import os
import xbmcvfs





def correctPVR():

	addon = xbmcaddon.Addon('script.module.authorize')
	username = addon.getSetting(id='Username')
	password = addon.getSetting(id='Password')
	kemo = xbmcaddon.Addon('plugin.video.kemo')	
	host = kemo.getSetting(id='host')
	m3uport = kemo.getSetting(id='m3uport')
	port = kemo.getSetting(id='port')
	jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'
	IPTVon 	   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
	nulldemo   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
	loginurl   = '%s:%s/playlist/%s/%s/m3u_plus?key=live' %(host,m3uport,username,password)
	#loginurl   = '%s:%s/streams/hls/%s' %(host,port,password)
	EPGurl     = '%s:%s/xmltv.php?username=%s&password=%s' %(host,port,username,password)
	#EPGurl     = '%s:%s/guide/%s/guide.xml' %(host,port,password)
	GroupsFile = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.kemo/resources/customTVGroups.xml'))
	removetv = xbmcvfs.translatePath('special://home/userdata/Database/TV38.db')
	removeepg = xbmcvfs.translatePath('special://home/userdata/Database/Epg13.db')
	useragent = 'User-Agent=VLC'

	xbmc.executeJSONRPC(jsonSetPVR)
	xbmc.executeJSONRPC(IPTVon)
	xbmc.executeJSONRPC(nulldemo)
	
	moist = xbmcaddon.Addon('pvr.iptvsimple')
	moist.setSetting(id='m3uUrl', value=loginurl)
	moist.setSetting(id='epgUrl', value=EPGurl)
	moist.setSetting(id='customTvGroupsFile', value=GroupsFile)	
	moist.setSetting(id='m3uCache', value="false")
	moist.setSetting(id='epgCache', value="false")
	moist.setSetting(id='defaultUserAgent', value=useragent)
	moist.setSetting(id='tvGroupMode', value="2")	
	moist.setSetting(id='m3uPathType', value="1")	
	xbmc.executebuiltin("Container.Refresh")
	xbmcvfs.delete(removetv)
	xbmcvfs.delete(removeepg)
	xbmc.sleep(500)
	done()  
          

	

def correctPVRfull():

	addon = xbmcaddon.Addon('script.module.authorize')
	username = addon.getSetting(id='kemo.username')
	password = addon.getSetting(id='kemo.password')
	kemo = xbmcaddon.Addon('plugin.video.kemo')	
	host = kemo.getSetting(id='host')
	m3uport = kemo.getSetting(id='m3uport')
	port = kemo.getSetting(id='port')
	jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'
	IPTVon 	   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
	nulldemo   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
	loginurl   = '%s:%s/playlist/%s/%s/m3u_plus?key=live' %(host,m3uport,username,password)
	#loginurl   = '%s:%s/streams/hls/%s' %(host,port,password)
	EPGurl     = '%s:%s/xmltv.php?username=%s&password=%s' %(host,port,username,password)
	#EPGurl     = '%s:%s/guide/%s/guide.xml' %(host,port,password)
	GroupsFile = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.kemo/resources/customTVGroupsfull.xml'))
	removetv = xbmcvfs.translatePath('special://home/userdata/Database/TV38.db')
	removeepg = xbmcvfs.translatePath('special://home/userdata/Database/Epg13.db')
	useragent = 'User-Agent=VLC'
	
	xbmc.executeJSONRPC(jsonSetPVR)
	xbmc.executeJSONRPC(IPTVon)
	xbmc.executeJSONRPC(nulldemo)
	
	moist = xbmcaddon.Addon('pvr.iptvsimple')
	moist.setSetting(id='m3uUrl', value=loginurl)
	moist.setSetting(id='epgUrl', value=EPGurl)
	moist.setSetting(id='customTvGroupsFile', value=GroupsFile)	
	moist.setSetting(id='m3uCache', value="false")
	moist.setSetting(id='defaultUserAgent', value=useragent)
	moist.setSetting(id='epgCache', value="false")
	moist.setSetting(id='tvGroupMode', value="2")	
	moist.setSetting(id='m3uPathType', value="1")	
	xbmc.executebuiltin("Container.Refresh")
	xbmcvfs.delete(removetv)
	xbmcvfs.delete(removeepg)
	xbmc.sleep(500)
	done()   
 
	
def done():
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.iptv.recorder","enabled":true}}') 	
	dialog = xbmcgui.Dialog()
	dialog.ok("SYNC", "[COLOR red][B]!!!DONE!!![/B][/COLOR]")  


xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":true}}')
choice = xbmcgui.Dialog().yesno('EPG SETUP', 'Would you like the full TV guide (SLOWER) or would you like the most popular catagories from USA, CANADA & UK?', nolabel='POPULAR',yeslabel='FULL', autoclose=int(20000))
if choice == 0: #NO LABEL popular
	correctPVR()

elif choice == 1: # YES LABEL full
	correctPVRfull()