# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import sys
import os
import xbmc, xbmcgui, xbmcvfs
import time, datetime


file = 'iptv.m3u8'
location = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groups/')
path = os.path.join(location, file)
if os.path.exists(path):
	os.remove(path)
	
file = 'iptv.m3u8'
location = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groupsfull/')
path = os.path.join(location, file)
if os.path.exists(path):
	os.remove(path)

file = 'settings.xml'
location = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groups/')
path = os.path.join(location, file)
if os.path.exists(path):
	os.remove(path)
	
file = 'settings.xml'
location = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groupsfull/')
path = os.path.join(location, file)
if os.path.exists(path):
	os.remove(path)

file = 'settings.xml'
location = xbmc.translatePath('special://home/userdata/addon_data/pvr.iptvsimple/')
path = os.path.join(location, file)
if os.path.exists(path):
	os.remove(path)
	
file = 'settings.xml'
location = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.kemo/')
path = os.path.join(location, file)
if os.path.exists(path):
	os.remove(path)
	
xbmc.sleep(200)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":false}}') 
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":false}}') 
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemobackup","enabled":false}}') 
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.program.iptv.groupsfull","enabled":false}}') 
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.program.iptv.groups","enabled":false}}') 
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.demo","enabled":false}}') 

xbmc.executebuiltin('Dialog.Close(busydialog)')