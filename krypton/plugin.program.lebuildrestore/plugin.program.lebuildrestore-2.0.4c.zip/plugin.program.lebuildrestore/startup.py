# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.lebuildrestore/'))



choice = xbmcgui.Dialog().yesno('UPGRADE AVAILABLE', 'There is an upgrade available for your box. Would you like to download  it now? YOU MAY NEED A WIRED KEYBOARD OR WIRED INTERNET TO SET UP NEW BUILD !!!!IMPORTANT!!!! IF YOUR BOX HAS AN SD CARD THEN DO NOT UPDATE. CONTACT ME FOR HELP.', nolabel='NO',yeslabel='YES')
if choice == 0:
	xbmc.executebuiltin("Home")
elif choice == 1: 
	dialog = xbmcgui.Dialog().select('SELECT YOUR BOX TO DOWNLOAD THE FILES', ['BEELINK MXIII II','Nexbox','Tanix TX7','Vorke Z6 (Not the plus model)','TX92','Tanix TX9 Pro & Vorke Z6 Plus'])
	if dialog==0:
		#BEELINK MXIII II
		xbmcvfs.copy('special://home/addons/plugin.program.lebuildrestore/resources/device_trees/beelink.img','storage/.update/beelink.img')
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.lebuildrestore/resources/upgrade.py)')
	elif dialog==1:
		#Nexbox
		xbmcvfs.copy('special://home/addons/plugin.program.lebuildrestore/resources/device_trees/nexbox.img','storage/.update/nexbox.img')
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.lebuildrestore/resources/upgrade.py)')		
	elif dialog==2:
		#TX7
		xbmcvfs.copy('special://home/addons/plugin.program.lebuildrestore/resources/device_trees/tx7.img','storage/.update/tx7.img')
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.lebuildrestore/resources/upgrade.py)')
	elif dialog==3:
		#Vorke
		xbmcvfs.copy('special://home/addons/plugin.program.lebuildrestore/resources/device_trees/vorke.img','storage/.update/vorke.img')
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.lebuildrestore/resources/upgrade.py)')
	elif dialog==4:
		#Tanix & Vontar TX92
		xbmcvfs.copy('special://home/addons/plugin.program.lebuildrestore/resources/device_trees/tx92.img','storage/.update/tx92.img')
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.lebuildrestore/resources/upgrade.py)')
	elif dialog==5:
		#Tanix TX9 Pro and Vorke Z6 Plus
		xbmcvfs.copy('special://home/addons/plugin.program.lebuildrestore/resources/device_trees/tx9pro.img','storage/.update/tx9pro.img')
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.lebuildrestore/resources/upgrade.py)')