import os

xbmc.executebuiltin('RunAddon(plugin.video.kemo)')
 
#xbmc.executebuiltin('Addon.OpenSettings(plugin.video.kemo)')