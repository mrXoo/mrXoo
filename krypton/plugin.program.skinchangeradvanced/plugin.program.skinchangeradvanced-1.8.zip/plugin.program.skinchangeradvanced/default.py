# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time
import xbmc, sys

xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.skinchangeradvanced/'))


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('plugin.program.skinchangeradvanced')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:


        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.estuary"}}')
        # xbmc.sleep(500)
        # xbmcvfs.copy('special://home/addons/script.addon.importer.linux/stuff/userdata/addon_data/skin.xonfluence/settings.xml','special://profile/addon_data/skin.xonfluence/settings.xml')
        # xbmcvfs.copy('special://home/addons/script.addon.importer.android/stuff/userdata/addon_data/skin.xonfluence/settings.xml','special://profile/addon_data/skin.xonfluence/settings.xml')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.xonfluence"}}')
        # xbmc.executebuiltin('SendClick(11)')
        # xbmc.sleep(500)
		#xbmc.executebuiltin('RunAddon(script.addon.importer.linux)')
		xbmc.executebuiltin('XBMC.RunScript(special://home/addons/plugin.program.skinchangeradvanced/resources/update.py)')