from xbmcswift2 import Plugin
from xbmcswift2 import actions
import xbmc,xbmcplugin,xbmcaddon,xbmcvfs,xbmcgui




import re
from urllib.parse import urljoin,quote,unquote
import sys
import json
import time
import os
from sanitize_filename import sanitize



def log(v):
    xbmc.log(repr(v), xbmc.LOGERROR)

def addon_id():
    return xbmcaddon.Addon().getAddonInfo('id')

def get_icon_path(icon_name):
    return "special://home/addons/%s/resources/img/%s.png" % (addon_id(),icon_name)


plugin = Plugin()



@plugin.route('/download/<url>/<name>')
def download(url,name):
    #log(url)
    filename = unquote(url).split('/')[-1]
    dst = xbmcaddon.Addon().getSetting('dir')
    dst = xbmcvfs.translatePath(dst)
    dst = os.path.join(dst,f"{sanitize(name)}")
    xbmcvfs.mkdirs(dst)
    ts = time.time()
    dst = os.path.join(dst,f"{ts}.mp4")
    dialog = xbmcgui.Dialog()
    #log(("Started Downloading",name,url,dst))
    dialog = xbmcgui.Dialog()
    dialog.notification("Started Downloading",name,sound=False)
    xbmcvfs.copy(url,dst)
    #log(("Finished Downloading",name))
    dialog.notification("Finished Downloading",name,sound=False)
    
@plugin.route('/download_queue')
def download_queue():
    info_type = "queue"
    previous_list = get_list(info_type)
    for url,label in previous_list:
        #log(('download',url,label))
        download(url,label)
        remove_item(url,label)


def get_list(list_type,default=[]):
    filename = xbmcvfs.translatePath(f'special://profile/addon_data/{addon_id()}/{list_type}.json')
    try:
        with open(filename) as f:
            previous_list = json.load(f)
    except:
        previous_list = default
    return previous_list

def save_list(list_type, seach_list):
    filename = xbmcvfs.translatePath(f'special://profile/addon_data/{addon_id()}/{list_type}.json')
    with open(filename,"w") as f:
        json.dump(seach_list,f)

@plugin.route('/remove_item/<url>/<label>')
def remove_item(url, label):
    list_type = 'queue'
    previous_list = get_list(list_type)
    what = [url,label]
    #log(('remove_item',what))
    if what in previous_list:
        previous_list.remove(what)
    save_list(list_type, previous_list)
    
@plugin.route('/add_item/<url>/<label>')
def add_item(url, label):
    list_type = 'queue'
    previous_list = get_list('queue')
    what = [url,label]
    if what not in previous_list:
        previous_list.append(what)
    save_list(list_type, previous_list)
    
    
@plugin.route('/show_queue')
def show_queue():
    items = []
    info_type = "queue"
    previous_list = get_list(info_type)
    for url,label in previous_list:
        #log((url,label))
        context_items = []
        context_items.append(('Remove', 'RunPlugin(%s)' % (plugin.url_for('remove_item', url=url, label=label))))
        items.append(
        {
            'label': label,
            'path': url,
            'is_playable': True,
            'thumbnail': get_icon_path('search'),
            'context_menu' : context_items,
        })
    return items    

@plugin.route('/')
def index():
    items = []


    items.append(
    {
        'label': "Downloads",
        'path': xbmcaddon.Addon().getSetting('dir'),
        'thumbnail': get_icon_path('most_watched'),
    })
    items.append(
    {
        'label': "Queue",
        'path': plugin.url_for(show_queue),
        'thumbnail': get_icon_path('cloud'),
    })

    return items

if __name__ == '__main__':
    plugin.run()


