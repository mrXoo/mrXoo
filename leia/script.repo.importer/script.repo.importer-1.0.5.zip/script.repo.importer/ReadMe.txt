Put the repo or addon in the stuff folder

Read line 15 IN THE service.py file for info on enabling the repo or script