# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.cefirmware/'))


choice = xbmcgui.Dialog().yesno('KODI MATRIX UPGRADE', 'Would you like to upgrade your firmware to KODI MATRIX? If unsucessful NONE of your settings will have been changed', nolabel='NO',yeslabel='YES')
if choice == 0:
	xbmc.executebuiltin("Home")
	
	############################################# FIRMWARE UPDDATE TO MATRIX  ###########################################
	
elif choice == 1:  
	dialog = xbmcgui.Dialog()
	dialog.ok("KODI MATRIX UPGRADE", "[COLOR red][B]!!!ATTENTION!!![/B][/COLOR] IT WILL TAKE SOME TIME TO COMPLETE THE DOWNLOAD PLEASE BE PATIENT")           
	url = 'https://github.com/CoreELEC/CoreELEC/releases/download/19.3-Matrix/CoreELEC-Amlogic-ng.arm-19.3-Matrix.tar'
	fileName = (os.path.join('storage/.update/','restore.tar')) 
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()	
	time.sleep(2)
	
	######################################### TO RESTORE NEW MATRIX BUILD  ###########################################
	
	# url = 'https://www.dropbox.com/s/6h4v5u8iscuxvjp/matrix.tar?dl=1'	
	# if not os.path.exists('storage/.restore/'):   
		# os.makedirs('storage/.restore/')         		
	# fileName = (os.path.join('storage/.restore/','20210903185157.tar'))         
	# req = requests.get(url)
	# file = open(fileName, 'wb')
	# for chunk in req.iter_content(100000):
		# file.write(chunk)
	# file.close()
	# dialog = xbmcgui.Dialog()
	# dialog.ok("KODI MATRIX UPGRADE", "PRESS [B]OK[/B] TO ENABLE A REBOOT [COLOR red][B]!!!WARNING!!![/B][/COLOR] NEXT YOUR BOX WILL REBOOT TWICE. IT MAY TAKE MANY MINUTES TO COMPLETE THE RESTORE PROCESS. YOUR SCREEN WILL GO BLACK")
	# dialog = xbmcgui.Dialog()
	# dialog.ok("KODI MATRIX UPGRADE", "[COLOR red][B]!!!ATTENTION!!![/B][/COLOR] YOU WILL HAVE TO RECONNECT TO WIFI AND RE-AUTHOURIZE YOUR STREAMING ACCOUNTS. BOX WILL NOW REBOOT")           
	# time.sleep(2)	
	xbmc.executebuiltin('Reboot')
	#xbmc.executebuiltin("Home")