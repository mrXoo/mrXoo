import os

def flawless():
		xbmc.executebuiltin('InstallAddon(plugin.video.madtitansports)')
flawless()