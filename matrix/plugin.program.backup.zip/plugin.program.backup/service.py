# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)


def copytree(src, dst):
    names = os.listdir(src)

    try:os.makedirs(dst)
    except:pass

    for name in names:
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)
        try:
            if os.path.isdir(srcname):
                copytree(srcname, dstname)
            else:
                shutil.copy(srcname, dstname)
        except Exception as e:
            print (e)

		################# SERVICE XML      BACKUP      ##########################

def backup ():

        slash   = ('/')	
        drive	= xbmcaddon.Addon().getSetting('Drive')
        database_folder  = xbmc.translatePath('special://home/userdata/Database')	
        source_folder = xbmc.translatePath('special://home/userdata/addon_data/')	
        #source_network = ('C:/Users/ED/Documents/')
        source_network = ('/storage/.cache/connman/')		
        connman = ('/connman/')
        kodi = ('/.kodi/')
        addons  = ('/addons/')
        userdata = ('/userdata/')
        addon_data = ('/addon_data/')
        database = ('Database/')
        addon_folder = xbmc.translatePath('special://home/addons/')	
		
		
        time.sleep(3600)	

			
################################ MAKE ALL DIRS ############################################################

		
        if not os.path.exists(drive + connman):  
            os.makedirs(drive + connman)        

        if not os.path.exists(drive + kodi + addons):  
            os.makedirs(drive + kodi + addons)         


        if not os.path.exists(drive + kodi + userdata + database):  
            os.makedirs(drive + kodi + userdata + database)         


        if not os.path.exists(drive + kodi + userdata + addon_data):  
            os.makedirs(drive + kodi + userdata + addon_data) 

		
############################### COPY CONNMAN WIFI SETTINGS TO FOLDER /media/connman #######################
 	
        from distutils.dir_util import copy_tree
        copy_tree(source_network, drive + connman)
		
		
###################  COPY ADDONS TO media/.kodi/addons #############################################################			

        addon = "plugin.program.backup"
        from distutils.dir_util import copy_tree
        copy_tree(addon_folder + addon, drive + kodi + addons + addon)

        addon = "plugin.program.cerestore"
        from distutils.dir_util import copy_tree
        copy_tree(addon_folder + addon, drive + kodi + addons + addon)

		
############################# COPY ADDONS DB FILES TO /media/.kodi/userdata/Database  #############################################

        xbmcvfs.copy('special://home/userdata/Database/MyVideos116.db',drive + kodi + userdata + database + 'MyVideos116.db')
        xbmcvfs.copy('special://home/userdata/Database/ViewModes6.db',drive + kodi + userdata + database + 'ViewModes6.db')
        xbmcvfs.copy('special://home/userdata/Database/Addons27.db',drive + kodi + userdata + database + 'Addons27.db')
        xbmcvfs.copy('special://home/userdata/Database/Addons33.db',drive + kodi + userdata + database + 'Addons33.db')
        xbmcvfs.copy('special://home/userdata/favorites.xml',drive + kodi + userdata + 'favourites.xml')				
        xbmcvfs.copy('special://home/userdata/sources.xml',drive + kodi + userdata + 'sources.xml')

		
	############################### COPY ADDON_DATA TO media/.kodi/userdata/addon_data/ ###################
	
	####################################################### COPY THE SECTION BELOW TO ADD PLUGINS #################################

        addon = "script.plex"
# fetch all files
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):
    # construct full file path
            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name
    # copy only files
            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
	#####################################################################################################################

			
        addon = "plugin.video.kemo"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				


        addon = "plugin.video.shadow"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
				
				
        addon = "plugin.video.seren"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				

				
        addon = "plugin.video.themoviedb.helper"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)


				
        addon = "script.module.myaccounts"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				

				
        addon = "script.module.resolveurl"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
				
        addon = "script.realdebrid"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				


				
        addon = "script.trakt"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				

				
        addon = "service.coreelec.settings"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				

        addon = "plugin.program.backup"
        if not os.path.exists(drive + kodi + userdata + addon_data + addon):   
            os.makedirs(drive + kodi + userdata + addon_data + addon)       
        if not os.path.exists(source_folder + addon):   
            os.makedirs(source_folder + addon)          			
		
        for file_name in os.listdir(source_folder + addon):

            source = source_folder + addon + slash + file_name
            destination = drive + kodi + userdata + addon_data + addon + slash + file_name

            if os.path.isfile(source):
                shutil.copy(source, destination)
                print('copied', file_name)
				
        
        time.sleep(60)

while True: backup()
