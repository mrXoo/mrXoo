import xbmc

xbmc.executebuiltin("RunPlugin(plugin://script.extendedinfo/?info=alltvshows)")