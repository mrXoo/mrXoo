# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))
def skinvariables():
	root= xbmc.translatePath('special://home/userdata/addon_data/script.skinvariables/')
	url = 'https://github.com/mrXoo/zips/raw/main/19/script.skinvariables/skin.arctic.horizon-viewtypes.json'     
	#os.makedirs(root, exist_ok=True) 		
	fileName = (os.path.join(root,'skin.arctic.horizon-viewtypes.json'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()

def horizon():
	root= xbmc.translatePath('special://home/userdata/addon_data/skin.arctic.horizon/')
	url = 'https://github.com/mrXoo/zips/raw/main/19/skin.arctic.horizon/settings.xml'     
	#os.makedirs(root, exist_ok=True) 		
	fileName = (os.path.join(root,'settings.xml'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()
	
skinvariables()
horizon()

xbmc.executebuiltin('ReloadSkin()') 