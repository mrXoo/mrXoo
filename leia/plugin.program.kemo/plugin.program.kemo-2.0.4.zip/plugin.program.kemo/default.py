# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import sys
import os
import xbmc, xbmcgui, xbmcvfs
import time, datetime








def ENABLEADDON():	
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.program.iptv.groupsfull","enabled":true}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.program.iptv.groups","enabled":true}}') 
	xbmc.sleep(200)
	
	xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/start.py)')
	       
def DISABLEADDON():
	file = 'iptv.m3u8'
	location = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groups/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)
		
	file = 'iptv.m3u8'
	location = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groupsfull/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)

	file = 'settings.xml'
	location = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groups/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)
		
	file = 'settings.xml'
	location = xbmc.translatePath('special://home/userdata/addon_data/plugin.program.iptv.groupsfull/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)

	file = 'settings.xml'
	location = xbmc.translatePath('special://home/userdata/addon_data/pvr.iptvsimple/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)
		
	file = 'settings.xml'
	location = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.kemo/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)
		
	xbmc.sleep(200)
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":false}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":false}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.program.iptv.groupsfull","enabled":false}}') 
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.program.iptv.groups","enabled":false}}') 

	xbmc.executebuiltin('Dialog.Close(busydialog)')
			

##########################################################################################################################################
choice = xbmcgui.Dialog().yesno('KEMO INSTALL', 'Do you have a username and password for KEMO IPTV? !!!NOTE!!! Click NO to uninstall KEMO IPTV', nolabel='YES',yeslabel='NO')
if choice == 1:
	DISABLEADDON()

elif choice == 0: 
	ENABLEADDON()


	
# if __name__ == "__main__":
    # main()