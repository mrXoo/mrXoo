#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs, os
import time
xbmc.executebuiltin('Action(Right)') 
xbmc.sleep(1000)
xbmc.executebuiltin('Action(Select)')

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.iptvsimple","enabled":true}}') 
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":true}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemobackup","enabled":true}}') 	
xbmc.sleep(200)

xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/start.py)')