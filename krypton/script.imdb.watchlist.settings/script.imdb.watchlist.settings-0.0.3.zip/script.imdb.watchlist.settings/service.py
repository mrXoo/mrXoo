# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time
import xbmc, sys

xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.video.imdb.watchlists/'))


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('script.imdb.watchlist.settings')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:

        while True:
            xbmcvfs.copy('special://home/addons/script.imdb.watchlist.settings/resources/settings.xml','special://profile/addon_data/plugin.video.imdb.watchlists/settings.xml')
            time.sleep(20)
            #time.sleep(14400)