import os


	#xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemobackup","enabled":true}}') 	
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.iptv.recorder","enabled":true}}') 	
xbmc.sleep(200)
	
xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/start.py)')