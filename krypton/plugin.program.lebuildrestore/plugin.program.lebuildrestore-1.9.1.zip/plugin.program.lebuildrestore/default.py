# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.lebuildrestore/'))



choice = xbmcgui.Dialog().yesno('KRYPTON RESTORE', 'Would you like to download and fresh build now?', nolabel='NO',yeslabel='YES')
if choice == 0:
	xbmc.executebuiltin("Home")
elif choice == 1:  
	dialog = xbmcgui.Dialog()
	dialog.ok("KRYPTON RESTORE", "[COLOR red][B]!!!ATTENTION!!![/B][/COLOR] THIS WILL TAKE SOME TIME TO COMPLETE THE DOWNLOAD PLEASE BE PATIENT")           
	#url = 'https://github.com/mrXoo/zips/raw/main/restore/restore.tar'
	url = 'https://www.dropbox.com/s/xkucuuvxt64pcgn/krypton.tar?dl=1'
	#fileName = (os.path.join('E:/storage','restore.tar'))
	fileName = (os.path.join('storage/.restore','20210903185157.tar'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()
	dialog = xbmcgui.Dialog()
	dialog.ok("KRYPTON RESTORE", "[COLOR red][B]!!!REMEMBER!!![/B][/COLOR] YOU WILL HAVE TO RECONNECT WIFI AND CARRY OUT A SCREEN CALIBRATION Visit www.bit.ly/2jevaok for setup instructions")
	dialog = xbmcgui.Dialog()
	dialog.ok("KRYPTON RESTORE", "PRESS [B]OK[/B] TO ENABLE A REBOOT [COLOR red][B]!!!WARNING!!![/B][/COLOR] DO NOT POWER OFF BOX WHEN UPDATE IS IN PROGRESS")
	time.sleep(2)	
	xbmc.executebuiltin('Reboot')
	#xbmc.executebuiltin("Home")