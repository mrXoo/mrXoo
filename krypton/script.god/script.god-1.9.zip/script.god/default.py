import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'script.god'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='script.god'
AddonTitle="LibreELEC Build Restore"
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/')) 
VERSION = "0.0.1"
DP = xbmcgui.DialogProgress()
PATH = "Build Restore"            
BASEURL = "Build Restore"
################################### CHANGE ON INDEX LINE ALSO #########################
BASEURL2 = "https://www.dropbox.com/s/h831mu2z7be341k/"
H = 'http://'


	
	#elif mode==4
def INDEX():#KRYPTON(): KRYPTON ONLY OPTION RIGHT NOW
	xbmc.executebuiltin(' ActivateWindow(10001,plugin://script.god/?description&fanart=D%3a%5cKODI%5cportable_data%5caddons%5cscript.god%5cfanart.jpg&iconimage=D%3a%5cKODI%5cportable_data%5caddons%5cscript.god%5cresources%5cart%5cvorke.png&mode=2&name=GOOGLEFIX&url=https%3a%2f%2fwww.dropbox.com%2fs%2fh831mu2z7be341k%2f%2fgooglefix.zip%3fdl%3d1,return)' )

#################################
####LIBREELEC BUILD RESTORE################
#################################
TARGETFOLDER = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.google/')

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


def UPDATER(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("GOOGLE FIX","DOWNLOADING THE FIX ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    #addonfolder = (os.path.join('I:','S905X'))
    time.sleep(5)
    dp.update(0,"", "APPLYING THE FIX")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)	
    #xbmc.executebuiltin('home')
    xbmc.executebuiltin('reboot')

    
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()
		
elif mode==2:
        UPDATER(name,url,description)

		

        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
