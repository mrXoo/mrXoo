Open putty or a cmd in windows and type the following:

ping powersports.ml
The response should give you the IP address to use for the hosts entry.

To edit your hosts file, do the following:

Mac/Linux

In the terminal, type

sudo nano /etc/hosts
When prompted, type your password. No characters will appear.

Windows

Open Notepad as Administrator (right-click -> Run as Administrator) Browse to C:\Windows\system32\drivers\etc\ and open "hosts"

Add or modify these lines that looks like this:

ip.from.previous.command mf.svc.nhl.com
ip.from.previous.command mlb-ws-mf.media.mlb.com

EACH ON THERE OWN LINE