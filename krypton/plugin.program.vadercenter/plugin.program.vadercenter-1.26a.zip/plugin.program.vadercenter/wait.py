# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time
import xbmc, sys
xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.vadercenter/'))


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('plugin.program.vadercenter')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:

	    time.sleep(1)
	    #xbmcvfs.copy('special://home/addons/video.lazyman.nhl.tv/hosts/hosts.conf','D:/KODI/portable_data/userdata/addon_data/video.lazyman.nhl.tv/hosts.conf')		
	    #xbmcvfs.copy('special://home/addons/video.lazyman.nhl.tv/hosts/hosts','D:/KODI/portable_data/userdata/addon_data/video.lazyman.nhl.tv/hosts')
	    xbmcvfs.copy('special://home/addons/plugin.program.vadercenter/resources/settings.xml','special://profile/addon_data/plugin.program.vadercenter/settings.xml')