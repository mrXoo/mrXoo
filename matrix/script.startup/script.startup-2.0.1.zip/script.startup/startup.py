#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs, os
import time

# xbmc.sleep(2000)
# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.estuary"}}')
# xbmc.executebuiltin('SendClick(11)')
# xbmc.sleep(2000)
# xbmcvfs.copy('special://home/addons/script.addon.importer.linux/stuff/userdata/addon_data/skin.xonfluence/settings.xml','special://profile/addon_data/skin.xonfluence/settings.xml')
# xbmcvfs.copy('special://home/addons/script.addon.importer.android/stuff/userdata/addon_data/skin.xonfluence/settings.xml','special://profile/addon_data/skin.xonfluence/settings.xml')
# xbmc.sleep(2000)
# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.xonfluence"}}')
# xbmc.executebuiltin('SendClick(11)')



dialog = xbmcgui.Dialog()
dialog.notification('[COLOR lime][B]LEIA CoreELEC[/B][/COLOR]', 'Welcome to Kodi', xbmcgui.NOTIFICATION_INFO, 10000)
time.sleep(20)	

TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/'
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/packages/'
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/temp/'
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

dialog = xbmcgui.Dialog()
dialog.notification('Addon Cleaner', 'Addons and packages purged.', xbmcgui.NOTIFICATION_INFO, 5000)

xbmc.executebuiltin("UpdateLocalAddons")
xbmc.executebuiltin("UpdateAddonRepos")
xbmc.executebuiltin( 'RunScript(plugin.video.themoviedb.helper, update_players)' )