# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net
import xbmc, sys
xbmc.log(repr(sys.argv))




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.program.libreelecupdater18'
addon= xbmcaddon.Addon()
path = addon.getAddonInfo('path').decode("utf-8") + "/icon.png"
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='plugin.program.libreelecupdater18'
AddonTitle="LibreELEC Updater"
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/')) 
VERSION = "0.0.1"
DP = xbmcgui.DialogProgress()
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "LibreELEC Updater"            
BASEURL = "https://archive.org/"
BASEURL1 = "https://github.com/mrXoo/zips/raw/main/" '''UPDATE'''
BASEURL3 = "https://www.dropbox.com/s/azqinqnbn473mz7/" '''GUI'''
H = 'http://'
EXCLUDES     = ['service.libreelec.settings','script.module.addon.common','repository.mredrepo','plugin.program.libreelecupdater18','plugin.program.lebuildrestore','plugin.program.lefirmwareupdate']

def INDEX():
	#addDir('INDEX',BASEURL,1,ART+'info.png',FANART,'')
	#addDir('INTERNAL BOOT',BASEURL,16,ART+'nand.png',FANART,'')
	addDir('CLICK TO UPDATE',BASEURL,22,ART+'update.png',FANART,'')
	addDir('MAINTENANCE',BASEURL,9,ART+'maintenance.png',FANART,'')
	#addDir('GUI FIX',BASEURL3+'/libreelecgui.zip?dl=1',24,ART+'guifix.png',FANART,'')
	setView('movies', 'MAIN')


def MAINTENANCE():
    #addDir('MAINTENANCE',BASEURL,9,ART+'maintenance1.png',FANART,'')
    #addDir('CLEAR CACHE','url',4,ART+'clearcache.png',FANART,'')
    #addDir('FRESH START','url',6,ART+'freshstart.png',FANART,'')
    addDir('ENABLE ADDONS',BASEURL,26,ART+'enableaddons.png',FANART,'')
    addDir('FRESH BUILD',BASEURL,27,ART+'freshbuild.png',FANART,'')
    addDir('IMPORTER FIX',BASEURL,7,ART+'importer.png',FANART,'')
    #addDir('DUAL BOOT',BASEURL,17,ART+'dualboot.png',FANART,'')
    addDir('GUI FIX',BASEURL3+'/libreelecgui18.zip?dl=1',24,ART+'guifix.png',FANART,'')
    setView('movies', 'MAIN')	
	
def MXQUPDATE():
	addDir('UPDATE BUILD',BASEURL1+'.zip',5,ART+'updatebuild.png',FANART,'') 
	setView('movies', 'MAIN')

#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

#######################################UPDATE BUILD 5 ##############################

def WIZARD(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.estuary"}}')
    #time.sleep(5)
    #xbmc.executebuiltin('Action(Right)')
    #time.sleep(2)
    #xbmc.executebuiltin('Action(Select)')
    #time.sleep(2)
    xbmc.executebuiltin('SendClick(11)')
    xbmc.sleep(500)
    xbmc.executebuiltin( 'ActivateWindow(Home)' )
    dp = xbmcgui.DialogProgress()
    dp.create("LibreELEC Updater","DOWNLOADING THE UPDATE ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(5)
    dp.update(0,"", "INSTALLING THE UPDATE")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    time.sleep(2)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.xonfluence"}}')
    #time.sleep(5)
    #xbmc.executebuiltin('Action(Right)')
    #time.sleep(2)
    #xbmc.executebuiltin('Action(Select)')
    #time.sleep(1)
    xbmc.executebuiltin('SendClick(11)')
    xbmc.sleep(500)
    xbmc.executebuiltin( 'ActivateWindow(Home)' )
    path = xbmc.translatePath(os.path.join('special://profile/addons/resources/'))
    time.sleep(2)
    WAIT()

def WAIT():
    path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.libreelecupdater18/'))


    if __name__ == '__main__':
        ADDON = xbmcaddon.Addon('plugin.program.libreelecupdater18')

        version = ADDON.getAddonInfo('version')
        if ADDON.getSetting('version') != version:

            time.sleep(1)
            xbmcvfs.copy('special://home/addons/plugin.program.libreelecupdater18/resources/network_wait','storage/.cache/libreelec/network_wait')
            xbmcvfs.copy('special://home/addons/plugin.program.libreelecupdater18/resources/x.txt','var/media/KODI/KIDS/x.txt')
            enableaddons()
			
######################################UPDATE OS 23 ###############################################	
def WIZARD1(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("LibreELEC Updater","DOWNLOADING THE FILES ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(5)
    dp.update(0,"", "INSTALLING THE FILES")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    time.sleep(5)
    dialog = xbmcgui.Dialog()
    dialog.ok("LibreELEC Updater", "FIRST CLICK [B]OK[/B], THEN CLICK THE DOTS, THEN CLICK THE BLUE ARROW TO RETURN TO THE MAIN UPDATE SCREEN AND CONTINUE ON WITH THE NEXT STEP")

	#################################FRESH BUILD OR GUI FIX 24 ###########################
def WIZARD2(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("LibreELEC Updater","DOWNLOADING THE GUI FIX ",'', 'PLEASE WAIT.........')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "INSTALLING THE GUI FIX")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("LibreELEC Updater", "TO SAVE CHANGES YOU NEED TO PULL THE POWER. AFTER CLICKING OK PULL THE PLUG AND REBOOT")
    killxbmc()

def BUILDRESTORE():
	xbmc.executebuiltin( 'RunAddon(plugin.program.lebuildrestore)' )
	#xbmc.executebuiltin('ActivateWindow(Home)')
	
	#################################
####ENABLE ADDONS KRYPTON########
#################################
	
#Makes log easier to follow:
def printstar():
	print "[COLOR white]***************************************************************************************"
	print "[COLOR white]***************************************************************************************"

	
def enableaddons():
	PATH = os.path.join(xbmc.translatePath('special://home/'), "addons")
	# Make some lists:
	ADDONS = []
	SUCCESS = []
	FAIL = []

	# Move stuff in or out of addons folder and then:
	xbmc.executebuiltin( 'UpdateLocalAddons' )
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin(' Notification(KODI WILL NOW REBOOT,Enjoy the new fixes and tweaks,6000, %s)' % (path))
	# Exclude addons I don't want to check (pvr is usually off on my system, metadata is the kodi repo stuff, packages folder obviously)
	for i in os.listdir(PATH):
		if os.path.isdir(os.path.join(PATH,i)) and 'packages' not in i and 'pvr' not in i and 'temp' not in i and 'metadata' not in i and 'plugin.video.fp' not in i:
			ADDONS.append(i)
	printstar()
	print ADDONS
	n = len(ADDONS)
	print ("There are %d addons in the kodi addons folder that will be checked." % n)
	printstar()
	# Check each addon - if not enabled try enable, then check status again.  Report success or fail.
	if n > 0:
		c = 0
		d = 0
		e = 0
		while c < n:
			CHECK = ADDONS[c]
			print ("Now checking %s ." % CHECK)
			if not xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % CHECK)
				xbmc.sleep(200)
				if xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
					d = d + 1
					SUCCESS.append(CHECK)
				else:
					# is addonid same as foldername?  If not get id from addon.xml and try again!
					ADDONXML = os.path.join(PATH, CHECK, "addon.xml")
					# get the addonid
					with open(ADDONXML) as f:
						for line in f:
							if "<addon id=" in line:
								start = "<addon id=\""
	#                            end = "\" name="
								end = "\""
								ADDONID = (line.split(start))[1].split(end)[0]
								print ('Folder is %s' % CHECK)
								print ('Addonid to enable is %s' % ADDONID)
								if not xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
									xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % ADDONID)            
									xbmc.sleep(200)
									if xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
										d = d + 1
										SUCCESS.append(CHECK)
									else:
										e = e + 1
										FAIL.append(CHECK)
					
			c = c + 1
	# If any failures put a message on the screen.
	ERROR = len(FAIL)
	if ERROR > 0:
		xbmcgui.Dialog().ok('Some addons were not enabled.', 'Check your log for details.')
	xbmc.sleep(200)
	#FOR UNIVERSAL BUILD NO REBOOT
	#xbmc.executebuiltin('ActivateWindow(Home)')
	#FOR LibreELEC AND EmbER BUILDS REBOOT COMMAND
	xbmc.executebuiltin('Reboot')
	
	# print results to log
	printstar()
	print ("[COLOR red]%s addons were checked" % n)
	print ("[COLOR red]%s addons were enabled" % d)
	print ("[COLOR red]There were %s failures" % e)
	print ("[COLOR red]Enabled addons: %s" % SUCCESS)
	print ("[COLOR red]Failures: %s" % FAIL)
	printstar()
	exit()
	
	

def ENABLEBUTTON():
   enableaddonsbutton()
   #enableaddons()
   
def enableaddonsbutton():
	dialog = xbmcgui.Dialog()
	dialog.ok("KRYPTON UPDATER", "ADDONS WILL NOW BE ENABLED.")
	PATH = os.path.join(xbmc.translatePath('special://home/'), "addons")
	# Make some lists:
	ADDONS = []
	SUCCESS = []
	FAIL = []

	# Move stuff in or out of addons folder and then:
	xbmc.executebuiltin( 'UpdateLocalAddons' )
	xbmc.executebuiltin("UpdateAddonRepos")

	# Exclude addons I don't want to check (pvr is usually off on my system, metadata is the kodi repo stuff, packages folder obviously)
	for i in os.listdir(PATH):
		if os.path.isdir(os.path.join(PATH,i)) and 'packages' not in i and 'pvr' not in i and 'temp' not in i and 'metadata' not in i:
			ADDONS.append(i)
	printstar()
	print ADDONS
	n = len(ADDONS)
	print ("There are %d addons in the kodi addons folder that will be checked." % n)
	printstar()
	# Check each addon - if not enabled try enable, then check status again.  Report success or fail.
	if n > 0:
		c = 0
		d = 0
		e = 0
		while c < n:
			CHECK = ADDONS[c]
			print ("Now checking %s ." % CHECK)
			if not xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % CHECK)
				xbmc.sleep(200)
				if xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
					d = d + 1
					SUCCESS.append(CHECK)
				else:
					# is addonid same as foldername?  If not get id from addon.xml and try again!
					ADDONXML = os.path.join(PATH, CHECK, "addon.xml")
					# get the addonid
					with open(ADDONXML) as f:
						for line in f:
							if "<addon id=" in line:
								start = "<addon id=\""
	#                            end = "\" name="
								end = "\""
								ADDONID = (line.split(start))[1].split(end)[0]
								print ('Folder is %s' % CHECK)
								print ('Addonid to enable is %s' % ADDONID)
								if not xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
									xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % ADDONID)            
									xbmc.sleep(200)
									if xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
										d = d + 1
										SUCCESS.append(CHECK)
									else:
										e = e + 1
										FAIL.append(CHECK)
					
			c = c + 1

			
			# Put results up on the screen:
		line1 = ('%d addons enabled'% d)
		line2 = ('%d addons not enabled'% e)
		line3 = 'Check the log for details.'
		
	if d > 0 and e > 0:
		xbmcgui.Dialog().ok(line1, line2, line3)
	elif e > 0:
		xbmcgui.Dialog().ok(line2, line3)
	elif d > 0:
		xbmcgui.Dialog().ok(line1, line3)
	elif d == 0 and e == 0:
		line3 = 'No action taken.'
		xbmcgui.Dialog().ok(line1, line3)
	else:
		line1 = 'Something funny going on.'
		xbmcgui.Dialog().ok(line1, line3)
	xbmc.sleep(200)
	xbmc.executebuiltin('ActivateWindow(Home)')
	
	# print results to log
	printstar()
	print ("[COLOR red]%s addons were checked" % n)
	print ("[COLOR red]%s addons were enabled" % d)
	print ("[COLOR red]There were %s failures" % e)
	print ("[COLOR red]Enabled addons: %s" % SUCCESS)
	print ("[COLOR red]Failures: %s" % FAIL)
	printstar()
	exit()
		
	
################################
###DELETE SCRIPT.ADDON.IMPORTER.LINUX DATA AND REPO.IMPORTER DATA##############MODE 7
############

def refresh(): 

    	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/script.addon.importer.linux/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

    	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/script.repo.importer/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
	#xbmc.executebuiltin('ActivateWindow(Home)')
	xbmc.executebuiltin('Reboot')

#################################
###DELETE CACHE##################
####THANKS GUYS @ XUNITY########
	
def deletecachefiles(url):
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
              # Set path to Cydia Archives cache files
                             

    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                
                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				

    dialog = xbmcgui.Dialog()
    dialog.ok("LibreELEC Updater", " All Cache Files Removed", "[COLOR steelblue]Brought To You By MR ED REPO[/COLOR]")
 
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################

def killxbmc():
    choice = xbmcgui.Dialog().yesno('Now Force Close Kodi', 'PULL THE POWER PLUG FROM THE BACK AND REBOOT', nolabel='DONT CLICK ME',yeslabel='DONT CLICK ME')
    if choice == 0:
        return
    elif choice == 1:
        return
##########################
###DETERMINE PLATFORM#####
##########################
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    
############################
###FRESH START##############
####THANKS TO TVADDONS######

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def FRESHSTART(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"[COLOR red][B]!!!WARNING!!![/B][/COLOR] ONLY CLICK YES IF YOU ARE SURE AS THIS WILL WIPE EVERYTHING")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath);
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0;
        DP.create(AddonTitle,"Clearing all files and folders:",'', '')
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    del_file += 1
                    DP.update(int(percentage(del_file, total_files)), '', 'File: [color=#000000]%s[/color]' % name, '')
					#ADD ANY FILES YOU DONT WANT DELETED HERE
                    if name in ['Addons27.db', 'kodi.log']: plugintools.log("Keep Log File: %s" % name)
                    else:
                        try: os.remove(os.path.join(root,name))
                        except:
                            if name not in ["Addons27.db","MyVideos99.db","Textures13.db","MyVideos107.db"]: failed=True
                            plugintools.log("Error removing "+root+" "+name)
                       
            for root, dirs, files in os.walk(xbmcPath,topdown=True):           
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in dirs:
                    DP.update(100, '', 'Cleaning Up Empty Folder: [color=#000000]%s[/color]' % name, '')
                    if name not in ["Database","userdata","temp","addons","addon_data"]:
                        shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)

            DP.close()
            if not failed: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,After reboot re-launch [COLOR lime][B]Krypton Updater[/B][/COLOR] Fresh Start,16500, %s)' % (path))
            else: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,After reboot click re-launch [COLOR lime][B]Krypton Updater[/B][/COLOR] Fresh Start,16500, %s)' % (path))
        except: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,Your settings have NOT been changed,16500, %s)' % (path))
    else: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,Your settings have NOT been changed,16500, %s)' % (path))
    xbmc.sleep(16500)	
    xbmc.executebuiltin('Reboot')
    #xbmc.executebuiltin('ActivateWindow(Home)')
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==2:
        BUILDMENU()

elif mode==3:
        SYSTEM()
		
elif mode==4:
        deletecachefiles(url)
		
elif mode==5:
        WIZARD(name,url,description)

elif mode==6:        
	FRESHSTART(params)
	
elif mode==7:
       refresh()

elif mode==8:
       INFO()
       
elif mode==9:
       MAINTENANCE()

elif mode==11:
        DELETEIVUEDB()

elif mode==12:
       OSINFO()
	   
elif mode==13:
       BUILDINFO()

elif mode==14:
       MOREINFO()
	   
elif mode==15:
       MYGICA()
	   
elif mode==16:
       MXQ()
	   	   
elif mode==17:
       MYGICASYSTEM()
	   
elif mode==18:
       MXQSYSTEM()
	   
elif mode==20:
       MXQKEYMAP()
	   	   	   
elif mode==21:
       MYGICAUPDATE()
	   
elif mode==22:
       MXQUPDATE()
	   
elif mode==23:
        WIZARD1(name,url,description)
		
elif mode==24:
        WIZARD2(name,url,description)	
	   
elif mode==26:
       ENABLEBUTTON()

elif mode==27:
       BUILDRESTORE()
		
elif mode==27:
		WAIT()	   
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
