# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import sys
import os
import xbmc, xbmcgui, xbmcvfs
import time, datetime



def main():
	choice = xbmcgui.Dialog().yesno('KEMO INSTALL', 'Do you have a username and password for KEMO IPTV?', nolabel='NO',yeslabel='YES')
	if choice == 0:
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/disable.py)')
	elif choice == 1: 
		ENABLEADDON()

def ENABLEADDON():	
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "plugin.video.kemo","enabled":true}}') 
	xbmc.sleep(200)
	
	xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.kemo/resources/start.py)')
	       


	




		
##########################################################################################################################################

	
if __name__ == "__main__":
    main()