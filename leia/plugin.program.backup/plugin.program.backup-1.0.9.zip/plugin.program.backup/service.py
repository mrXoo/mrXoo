# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)


def copytree(src, dst):
    names = os.listdir(src)

    try:os.makedirs(dst)
    except:pass

    for name in names:
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)
        try:
            if os.path.isdir(srcname):
                copytree(srcname, dstname)
            else:
                shutil.copy(srcname, dstname)
        except Exception as e:
            print (e)

		################# SERVICE XML      BACKUP      ##########################



slash   = ('/')	
drive	= xbmcaddon.Addon().getSetting('Drive')
media	= xbmcaddon.Addon().getSetting('Card')
database_folder  = xbmc.translatePath('special://home/userdata/Database')	
source_folder = xbmc.translatePath('special://home/userdata/addon_data/')
movies = xbmc.translatePath('/plugin.video.themoviedb.helper/movies')
tvshows = xbmc.translatePath('plugin.video.themoviedb.helper/tvshows')
#source_network = ('C:/Users/ED/Documents/')
source_network = ('/storage/.cache/connman/')
remote_folder = ('/storage/.config/rc_keymaps/')		
connman = ('/connman/')
kodi = ('.kodi/')
addons  = ('addons/')
userdata = ('userdata/')
addon_data = ('addon_data/')
database = ('Database/')
addon_folder = xbmc.translatePath('special://home/addons/')	
storage = ('storage/')
cache = ('.cache/')
config = ('.config/')
rc_keymaps = ('/rc_keymaps/')       





time.sleep(7200)	
#time.sleep(20)


############################### DELETE STORAGE ################################

TARGETFOLDER =(media + storage)
def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER =(drive + storage)
def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

time.sleep(120)
		
	################################ MAKE ALL DIRS ON MMEDIA FOR CONNMAN ############################################################

if not os.path.exists(media + storage + cache + connman):  
	os.makedirs(media + storage + cache + connman)

if not os.path.exists(drive + storage + cache + connman):  
	os.makedirs(drive + storage + cache + connman)  	

	################################ COPY CONNMAN SETTINGS ################################################

from distutils.dir_util import copy_tree
copy_tree(source_network, media + storage + cache + connman)

from distutils.dir_util import copy_tree
copy_tree(source_network, drive + storage + cache + connman)

####################################  MAKE REMOTE FILES DIRS ####################################################

if not os.path.exists(media + storage + config + rc_keymaps):  
	os.makedirs(media + storage + config + rc_keymaps)

if not os.path.exists(drive + storage + config + rc_keymaps):  
	os.makedirs(drive + storage + config + rc_keymaps)  	

	################################ COPY REMOTE FILES ###############################################

from distutils.dir_util import copy_tree
copy_tree(remote_folder, media + storage + config + rc_keymaps)

from distutils.dir_util import copy_tree
copy_tree(remote_folder, drive + storage + config + rc_keymaps)

xbmcvfs.copy('storage/.config/rc_maps.cfg',media + storage + config + 'rc_maps.cfg')
xbmcvfs.copy('storage/.config/rc_maps.cfg',drive + storage + config + 'rc_maps.cfg')
	 
	################################ MAKE DATABASE DIR ############################################################

if not os.path.exists(media + storage + kodi + userdata + database):  
	os.makedirs(media + storage + kodi + userdata + database) 

if not os.path.exists(drive + storage + kodi + userdata + database):  
	os.makedirs(drive + storage + kodi + userdata + database) 

	################################ COPY DATABASE FILES ############################################################

xbmcvfs.copy('special://home/userdata/Database/MyVideos107.db',media + storage + kodi + userdata + database + 'MyVideos107.db')
xbmcvfs.copy('special://home/userdata/Database/MyVideos116.db',media + storage + kodi + userdata + database + 'MyVideos116.db')
xbmcvfs.copy('special://home/userdata/Database/MyVideos119.db',media + storage + kodi + userdata + database + 'MyVideos119.db')
xbmcvfs.copy('special://home/userdata/Database/ViewModes6.db',media + storage + kodi + userdata + database + 'ViewModes6.db')
#xbmcvfs.copy('special://home/userdata/Database/Addons27.db',media + storage + kodi + userdata + database + 'Addons27.db')
#xbmcvfs.copy('special://home/userdata/Database/Addons33.db',media + storage + kodi + userdata + database + 'Addons33.db')
xbmcvfs.copy('special://home/userdata/favorites.xml',media + storage + kodi + userdata + 'favourites.xml')				
xbmcvfs.copy('special://home/userdata/sources.xml',media + storage + kodi + userdata + 'sources.xml')


xbmcvfs.copy('special://home/userdata/Database/MyVideos107.db',drive + storage + kodi + userdata + database + 'MyVideos107.db')
xbmcvfs.copy('special://home/userdata/Database/MyVideos116.db',drive + storage + kodi + userdata + database + 'MyVideos116.db')
xbmcvfs.copy('special://home/userdata/Database/MyVideos119.db',drive + storage + kodi + userdata + database + 'MyVideos119.db')
xbmcvfs.copy('special://home/userdata/Database/ViewModes6.db',drive + storage + kodi + userdata + database + 'ViewModes6.db')
#xbmcvfs.copy('special://home/userdata/Database/Addons27.db',drive + storage + kodi + userdata + database + 'Addons27.db')
#xbmcvfs.copy('special://home/userdata/Database/Addons33.db',drive + storage + kodi + userdata + database + 'Addons33.db')
xbmcvfs.copy('special://home/userdata/favorites.xml',drive + storage + kodi + userdata + 'favourites.xml')				
xbmcvfs.copy('special://home/userdata/sources.xml',drive + storage + kodi + userdata + 'sources.xml')


################################ MAKE DIR FOR ADDON ######################################
addon = "plugin.video.kemo"

if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)

#################################################################################################################################


addon = "plugin.program.iptv.groups"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "script.plex"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "plugin.video.themoviedb.helper"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "script.trakt"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "plugin.video.shadow"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "plugin.video.seren"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "script.module.resolveurl"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "script.realdebrid"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "service.coreelec.settings"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "plugin.program.backup"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "pvr.iptvsimple"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)



addon = "plugin.video.realizer"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)


addon = "plugin.video.foxystreams"
if not os.path.exists(media + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(media + storage + kodi + userdata + addon_data + addon)	
if not os.path.exists(drive + storage + kodi + userdata + addon_data + addon):   
	os.makedirs(drive + storage + kodi + userdata + addon_data + addon)		
if not os.path.exists(source_folder + addon):   
	os.makedirs(source_folder + addon)

#################################### COPY FILES IN ADDON ##########################################

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, media + storage + kodi + userdata + addon_data + addon)

from distutils.dir_util import copy_tree
copy_tree(source_folder + addon, drive + storage + kodi + userdata + addon_data + addon)
