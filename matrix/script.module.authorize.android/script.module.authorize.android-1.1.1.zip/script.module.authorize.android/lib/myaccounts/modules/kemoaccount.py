# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
import xbmc
import os
import xbmcvfs


dialog = xbmcgui.Dialog().select('SYNC', ['Account Info','Logout'])
if dialog==0:
	xbmc.executebuiltin('Action(PreviousMenu)') 
	xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.kemo/mode=1&url=url&xtra=test_parm,return)')
	time.sleep(7)
	xbmc.executebuiltin('RunAddon(script.module.authorize.android)')

elif dialog==1:
	xbmc.executebuiltin('Action(PreviousMenu)') 
	xbmc.executebuiltin('PlayMedia(plugin://plugin.video.kemo/?url=LO&mode=10&xtra=test_parm)')
	time.sleep(7)
	xbmc.executebuiltin('RunAddon(script.module.authorize.android)')