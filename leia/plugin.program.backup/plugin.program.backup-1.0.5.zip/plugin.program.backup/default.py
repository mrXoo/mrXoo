# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)


    
drive = xbmcaddon.Addon().getSetting('Drive')
media = xbmcaddon.Addon().getSetting('Card')
source_network = ('/storage/.cache/connman/')		
connman = ('/connman/')
kodi = ('/.kodi/')
addons  = ('/addons/')
userdata = ('/userdata/')
addon_data = ('/addon_data/')
database = ('Database/')
kodi_folder = ('/storage/.kodi/')
storage = ('/storage/')


src = (media + storage)
dst = (storage)
def copytree(src, dst):
    names = os.listdir(src)

    try:os.makedirs(dst)
    except:pass

    for name in names:
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)
        try:
            if os.path.isdir(srcname):
                copytree(srcname, dstname)
            else:
                shutil.copy(srcname, dstname)
        except Exception as e:
            print (e)


src = (drive + storage)
dst = (storage)
def copytree2(src, dst):
    names = os.listdir(src)

    try:os.makedirs(dst)
    except:pass

    for name in names:
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)
        try:
            if os.path.isdir(srcname):
                copytree(srcname, dstname)
            else:
                shutil.copy(srcname, dstname)
        except Exception as e:
            print (e)

##########################################################################################################################

choice = xbmcgui.Dialog().yesno('SETTINGS RESTORE', 'Would you like to restore your personal settings now?', nolabel='NO',yeslabel='YES')
if choice == 0:
	xbmc.executebuiltin("Home")
elif choice == 1: 



		############################### 	DELETE DATABASE FILES FOR WHEN UPGRADING VERSIONS  #######################


	file = 'MyVideos116.db'
	location = xbmc.translatePath('special://home/userdata/Database/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)


	file = 'MyVideos119.db'
	location = xbmc.translatePath('special://home/userdata/Database/')
	path = os.path.join(location, file)
	if os.path.exists(path):
		os.remove(path)
	
################################# RESTORE ALL KODI DATA ################################	

	copytree(src, dst)	
	copytree2(src, dst)	


# ################################  DELETE INVOKER ADDON FOR NEW BUILD  ###################################

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/script.firstrun/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	xbmc.executebuiltin('Reboot')
	#xbmc.executebuiltin("Addon.OpenSettings(plugin.video.youtube)")