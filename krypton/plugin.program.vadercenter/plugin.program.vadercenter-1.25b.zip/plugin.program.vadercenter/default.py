# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import ResetDatabase
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net
import xbmc, sys
import wait
xbmc.log(repr(sys.argv))




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.program.vadercenter'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='plugin.program.vadercenter'
AddonTitle="Global Setup"
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/')) 
VERSION = "0.0.1"
DP = xbmcgui.DialogProgress()
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Global Setup" 
########### VADER #########           
BASEURL = "https://www.dropbox.com/s/sbl0ava84rtvvhm/"
BASEURL2 = "https://www.dropbox.com/s/i6x39hdxg43dwjf/" 
BASEURL3 = "https://www.dropbox.com/s/b5687ey8wkow8bn/"
H = 'http://'

def INDEX():
	#addDir('INSTALL VOD',BASEURL2+'/vod.zip?dl=1',9,ART+'vod.png',FANART,'')
	addDir('INSTALL TVOB',BASEURL3+'/tvob.zip?dl=1',11,ART+'tvob.png',FANART,'')
	addDir('INSTALL EXODUS IPTV',BASEURL+'/exodusiptv.zip?dl=1',2,ART+'global.png',FANART,'')
	addDir('INSTALL RD',BASEURL2+'/rd.zip?dl=1',9,ART+'rd.png',FANART,'')
	addDir('DELETE EXODUS',BASEURL,3,ART+'delete.png',FANART,'')
	#addDir('FIX GUIDE',BASEURL,7,ART+'deleteepg.png',FANART,'')
	setView('movies', 'MAIN')

def FIXGUIDE():
	addDir('',BASEURL,0,ART+'selectguide.png',FANART,'')
	setView('movies', 'MAIN')	
	addDir('FIX ADDON GUIDE',BASEURL,5,ART+'fixaddonguide.png',FANART,'')
	setView('movies', 'MAIN')
	addDir('FIX KODI GUIDE',BASEURL,6,ART+'fixkodiguide.png',FANART,'')
	setView('movies', 'MAIN')
#######################################UPDATE BUILD 5 ##############################
def INSTALLFROMREPO():
    xbmc.executebuiltin('ActivateWindow(10040,addons://repository.vader-streams.tv/xbmc.addon.video,return)')

def WIZARD(name,url,description):
    xbmc.executebuiltin('ActivateWindow(Home)')
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("SETTING UP","DOWNLOADING THE ADDONS ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(5)
    dp.update(0,"", "INSTALLING THE ADDONS")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("SETTING UP", "KODI WILL NOW REBOOT, ENJOY YOUR STREAMING")
    path = xbmc.translatePath(os.path.join('special://profile/addons/resources/'))
    time.sleep(2)
    #WAIT()
    enableaddons()
	
def WIZARD_VOD(name,url,description):
    xbmc.executebuiltin('ActivateWindow(Home)')
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("SETTING UP","DOWNLOADING THE ADDONS ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(5)
    dp.update(0,"", "INSTALLING THE ADDONS")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("SETTING UP", "KODI WILL NOW REBOOT, ENJOY YOUR STREAMING")
    path = xbmc.translatePath(os.path.join('special://profile/addons/resources/'))
    time.sleep(2)
    #WAIT()
    #enableaddons()
    ERASEFORVOD()
    
def ERASEFORVOD():

    	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.tvobv1/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
    
    	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/Thumbnails/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
	enableaddons()


def WIZARD_TVOB(name,url,description):
    xbmc.executebuiltin('ActivateWindow(Home)')
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("SETTING UP","DOWNLOADING THE ADDONS ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(5)
    dp.update(0,"", "INSTALLING THE ADDONS")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("SETTING UP", "KODI WILL NOW REBOOT, ENJOY YOUR STREAMING")
    path = xbmc.translatePath(os.path.join('special://profile/addons/resources/'))
    time.sleep(2)
    #WAIT()
    #enableaddons()
    ERASEFORTVOB()
    
def ERASEFORTVOB():

    	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.vodv1/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
    
    	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/Thumbnails/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
	enableaddons()
	  
def WAIT():
    path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.vadercenter/'))


    if __name__ == '__main__':
        ADDON = xbmcaddon.Addon('plugin.program.vadercenter')

        version = ADDON.getAddonInfo('version')
        if ADDON.getSetting('version') != version:

            time.sleep(1)
            xbmcvfs.copy('special://home/addons/plugin.program.vadercenter/resources/network_wait','storage/.cache/libreelec/network_wait')
            enableaddons()
            #INSTALLFROMREPO()

			
def resetaddonguide():

    	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/script.tvguide.Vader/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
	xbmc.executebuiltin( 'RunAddon(script.tvguide.Vader)' )

	
def resetkodiguide():
    
	choice = xbmcgui.Dialog().yesno('GLOBAL SETUP', 'KODI WILL REBOOT, YOU WILL HAVE TO RE-ENTER YOUR USERNAME AND PASSWORD CLICK YES OR NO TO CONTINUE', nolabel='NO',yeslabel='YES')
	if choice == 0:
	#NO
		xbmc.executebuiltin('ActivateWindow(Home)')
	elif choice == 1:
	#YES
		path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.VADER'))
		lib=os.path.join(path,'settings.xml')
		if os.path.exists(path) :
			os.remove(lib)
			xbmc.executebuiltin('Reboot')
			#xbmc.executebuiltin('ActivateWindow(Home)')

			
def delete():
	#####################################################  ADDONS  ##################################

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.iptv.recorder/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.exodusv2/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)



	#####################################################  ADDON DATA  ##############################
	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.exosusv2/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)



	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/pvr.iptvsimple/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.iptv.recorder/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
	########################################### ACTIVATE WINDOW HOME  ##############################
	#xbmc.executebuiltin('ActivateWindow(Home)')
	xbmc.executebuiltin('Reboot')
	

#################################
####ENABLE ADDONS KRYPTON########
#################################
	
#Makes log easier to follow:
def printstar():
	print "[COLOR white]***************************************************************************************"
	print "[COLOR white]***************************************************************************************"

	
def enableaddons():
	PATH = os.path.join(xbmc.translatePath('special://home/'), "addons")
	# Make some lists:
	ADDONS = []
	SUCCESS = []
	FAIL = []

	# Move stuff in or out of addons folder and then:
	xbmc.executebuiltin( 'UpdateLocalAddons' )
	xbmc.executebuiltin("UpdateAddonRepos")

	# Exclude addons I don't want to check (pvr is usually off on my system, metadata is the kodi repo stuff, packages folder obviously)
	for i in os.listdir(PATH):
		if os.path.isdir(os.path.join(PATH,i)) and 'packages' not in i and 'pvr' not in i and 'temp' not in i and 'metadata' not in i and 'FD628Display' not in i:
			ADDONS.append(i)
	printstar()
	print ADDONS
	n = len(ADDONS)
	print ("There are %d addons in the kodi addons folder that will be checked." % n)
	printstar()
	# Check each addon - if not enabled try enable, then check status again.  Report success or fail.
	if n > 0:
		c = 0
		d = 0
		e = 0
		while c < n:
			CHECK = ADDONS[c]
			print ("Now checking %s ." % CHECK)
			if not xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % CHECK)
				xbmc.sleep(200)
				if xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
					d = d + 1
					SUCCESS.append(CHECK)
				else:
					# is addonid same as foldername?  If not get id from addon.xml and try again!
					ADDONXML = os.path.join(PATH, CHECK, "addon.xml")
					# get the addonid
					with open(ADDONXML) as f:
						for line in f:
							if "<addon id=" in line:
								start = "<addon id=\""
	#                            end = "\" name="
								end = "\""
								ADDONID = (line.split(start))[1].split(end)[0]
								print ('Folder is %s' % CHECK)
								print ('Addonid to enable is %s' % ADDONID)
								if not xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
									xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % ADDONID)            
									xbmc.sleep(200)
									if xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
										d = d + 1
										SUCCESS.append(CHECK)
									else:
										e = e + 1
										FAIL.append(CHECK)
					
			c = c + 1
	# If any failures put a message on the screen.
	ERROR = len(FAIL)
	if ERROR > 0:
		xbmc.executebuiltin('Reboot')
		#xbmc.executebuiltin('Home')

	xbmc.sleep(200)
	xbmc.executebuiltin('Reboot')
	#xbmc.executebuiltin('Home')
	
	# print results to log
	printstar()
	print ("[COLOR red]%s addons were checked" % n)
	print ("[COLOR red]%s addons were enabled" % d)
	print ("[COLOR red]There were %s failures" % e)
	print ("[COLOR red]Enabled addons: %s" % SUCCESS)
	print ("[COLOR red]Failures: %s" % FAIL)
	printstar()
	exit()
	
	        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
##########################
###DETERMINE PLATFORM#####
##########################
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    
############################
###FRESH START##############
####THANKS TO TVADDONS######

def percentage(part, whole):
    return 100 * float(part)/float(whole)

	        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')


def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()
		
elif mode==2:
        WIZARD(name,url,description)
  
elif mode==3:
        delete()
		
elif mode==4:
		WAIT()
		
elif mode==5:
        resetaddonguide()
		
elif mode==6:
        resetkodiguide()
		
elif mode==7:
		FIXGUIDE()
		
elif mode==8:
		INSTALLFROMREPO()
        
elif mode==9:
        WIZARD_VOD(name,url,description)
        
elif mode==10:
        ERASEFORVOD()

elif mode==11:
        WIZARD_TVOB(name,url,description)
        
elif mode==12:
        ERASEFORTVOB()          
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))
