# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.lebuildrestore/'))

dialog = xbmcgui.Dialog()
dialog.notification('UPGRADE IN PROGRESS', 'Please be patient', xbmcgui.NOTIFICATION_INFO, 200000,sound=True)         

url = 'https://gitlab.com/k2189/leia/-/raw/main/leia.tar'
#fileName = (os.path.join('D:/storage/.restore','20210903185157.tar'))
fileName = (os.path.join('storage/.restore','20210903185157.tar'))
req = requests.get(url)
file = open(fileName, 'wb')
for chunk in req.iter_content(100000):
	file.write(chunk)
file.close()

url = 'https://github.com/CoreELEC/CoreELEC/releases/download/9.2.8/CoreELEC-Amlogic.arm-9.2.8.tar'
#fileName = (os.path.join('D:/storage/.update','update.tar'))
fileName = (os.path.join('storage/.update','update.tar'))
req = requests.get(url)
file = open(fileName, 'wb')
for chunk in req.iter_content(100000):
	file.write(chunk)
file.close()

dialog = xbmcgui.Dialog()
dialog.notification('UPGRADE COMPLETE', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
time.sleep(5)
xbmc.executebuiltin('reboot')	
#xbmc.executebuiltin("Home")