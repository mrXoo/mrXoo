import xbmc,xbmcaddon,xbmcvfs,xbmcgui
import os
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
import time




def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)



dialog = xbmcgui.Dialog().select('KODI CONFIG SETTINGS', ['Power Menu','Open Kodi Settings','Open File Manager','CoreELEC Settings & WiFi Settings','Downloader','Remote & Front Display Files'])
if dialog==0:
	xbmc.executebuiltin('ActivateWindow(shutdownmenu)')

elif dialog==1:
	xbmc.executebuiltin('ActivateWindow(Settings)')

elif dialog==2:
	xbmc.executebuiltin('ActivateWindow(filemanager)')

elif dialog==3:
	xbmcgui.Dialog().ok('CoreELEC SETTINGS', 'Scroll to Connections and select your WiFi. Addon will open once you click OK')
	xbmc.executebuiltin('RunAddon(service.coreelec.settings)')
	
elif dialog==4:
	dialog = xbmcgui.Dialog().select('REAL DEBRID DOWNLOADER', ['Real Debrid Download area','Fen real debrid Download area'])

	if dialog==0:
		dialog = xbmcgui.Dialog().select('Real Debrid Downloader', ['Real Debrid links','Real Debrid Torrents'])
			
		if dialog==0:
			xbmc.executebuiltin('ActivateWindow(10001,plugin://script.realdebrid/?extras=%7b%27offset%27%3a%20%270%27%2c%20%27limit%27%3a%20%27100%27%7d&fanart=C%3a%2fUsers%2fED%2fDocuments%2fKODI%2fMATRIX%2fKodi%2fportable_data%2faddons%2fscript.realdebrid%2ffanart.jpg&icon=C%3a%2fUsers%2fED%2fDocuments%2fKODI%2fMATRIX%2fKodi%2fportable_data%2faddons%2fscript.realdebrid%2ficon.png&mode=2&name=View%20Unrestricted%20Links&poster=none&url,return)')
			xbmcgui.Dialog().ok('REAL DEBRID DOWNLOADER','On the next page press menu key or C on the link you want to download and select download.')		
		elif dialog==1:
			xbmc.executebuiltin('ActivateWindow(10001,plugin://script.realdebrid/?extras=%7b%27offset%27%3a%20%270%27%2c%20%27limit%27%3a%20%27100%27%7d&fanart=C%3a%2fUsers%2fED%2fDocuments%2fKODI%2fMATRIX%2fKodi%2fportable_data%2faddons%2fscript.realdebrid%2ffanart.jpg&icon=C%3a%2fUsers%2fED%2fDocuments%2fKODI%2fMATRIX%2fKodi%2fportable_data%2faddons%2fscript.realdebrid%2ficon.png&mode=1&name=View%20Torrents&poster=none&url,return)')
			xbmcgui.Dialog().ok('REAL DEBRID DOWNLOADER','On the next page press menu key or C on the link you want to download and select download.')
	elif dialog==1:
		dialog = xbmcgui.Dialog().select('FEN Downloader', ['FEN Links','FEN Torrents'])	
		if dialog==0:
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.fen/?mode=real_debrid.rd_downloads,return)')
			xbmcgui.Dialog().ok('FEN DOWNLOADER','On the next page press menu key or C on the link you want to download and select download.')		
		elif dialog==1:	
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.fen/?mode=real_debrid.rd_torrent_cloud,return)')
			xbmcgui.Dialog().ok('FEN DOWNLOADER','On the next page open the folder then select press menu key or C and select download File.')

elif dialog==5:
	dialog = xbmcgui.Dialog().select('SELECT YOUR BOX TO DOWNLOAD THE FILES', ['H96max round box','Tanix TX5 & TX3','X96 Max'])

	if dialog==0:
		# h96max
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/H96max/storage/.config/vfd.conf','storage/.config/vfd.conf')
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/H96max/storage/.config/rc_maps.cfg','storage/.config/rc_maps.cfg')
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/H96max/storage/.config/rc_keymaps/H96max','storage/.config/rc_keymaps/H96max')
		dialog = xbmcgui.Dialog()
		dialog.notification('CONFIGURATION SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('reboot')
	elif dialog==1:
		#TX 3 or 5
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/TX3_5/storage/.config/vfd.conf','storage/.config/vfd.conf')
		dialog = xbmcgui.Dialog()
		dialog.notification('CONFIGURATION SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('reboot')	
	elif dialog==2:
		#X96 max
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/X96max/storage/.config/vfd.conf','storage/.config/vfd.conf')
		dialog = xbmcgui.Dialog()
		dialog.notification('CONFIGURATION SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('reboot')