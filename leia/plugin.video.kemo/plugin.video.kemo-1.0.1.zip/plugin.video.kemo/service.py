# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time
import xbmc, sys
xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.video.kemo/'))


if __name__ == '__main__':
	ADDON = xbmcaddon.Addon('plugin.video.kemo')

	version = ADDON.getAddonInfo('version')
	if ADDON.getSetting('version') != version:
		ADDON.setSetting('version', version)

		time.sleep(2)
		xbmcvfs.copy('special://home/addons/plugin.video.kemo/resources/groups','special://home/userdata/addon_data/plugin.program.iptv.groups/.storage/groups')