# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time
import xbmc, sys
xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/video.lazyman.nhl.tv/'))


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('video.lazyman.nhl.tv')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:

	    time.sleep(32)
	    #xbmcvfs.copy('special://home/addons/video.lazyman.nhl.tv/hosts/hosts.conf','D:/KODI/portable_data/userdata/addon_data/video.lazyman.nhl.tv/hosts.conf')
	    xbmcvfs.copy('special://home/addons/video.lazyman.nhl.tv/hosts/hosts.conf','/storage/.config/hosts.conf')		
	    #xbmcvfs.copy('special://home/addons/video.lazyman.nhl.tv/hosts/hosts','D:/KODI/portable_data/userdata/addon_data/video.lazyman.nhl.tv/hosts')
	    xbmcvfs.copy('special://home/addons/video.lazyman.nhl.tv/hosts/hosts','/etc/hosts')
	    xbmcvfs.copy('special://home/addons/video.lazyman.nhl.tv/hosts/settings.xml','special://profile/addon_data/video.lazyman.nhl.tv/settings.xml')

