import xbmc,xbmcaddon,xbmcvfs,xbmcgui
import os
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
import time




def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)



dialog = xbmcgui.Dialog().select('KODI CONFIG SETTINGS', ['Power Menu','Open Kodi Settings','Open File Manager','CoreELEC Settings & WiFi Settings','Downloader','Remote & Front Display Files'])
if dialog==0:
	xbmc.executebuiltin('ActivateWindow(shutdownmenu)')

elif dialog==1:
	xbmc.executebuiltin('ActivateWindow(Settings)')

elif dialog==2:
	xbmc.executebuiltin('ActivateWindow(filemanager)')

elif dialog==3:
	xbmcgui.Dialog().ok('CoreELEC SETTINGS', 'Scroll to Connections and select your WiFi. Addon will open once you click OK')
	xbmc.executebuiltin('RunAddon(service.coreelec.settings)')

		
elif dialog==4:
	dialog = xbmcgui.Dialog().select('REAL DEBRID DOWNLOADER', ['Realizer Download area','Fen real debrid Download area'])

	if dialog==0:
		dialog = xbmcgui.Dialog().select('Realizer Downloader', ['Realizer links','Realizer Torrents'])
			
		if dialog==0:
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.realizer/?action=rdTransfers&page=1,return)')
			xbmcgui.Dialog().ok('REALIZER DOWNLOADER','On the next page press menu key or C on the link you want to download and select download from Cloud.')		
		elif dialog==1:
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.realizer/?action=rdTorrentList&page=1,return)')
			xbmcgui.Dialog().ok('REALIZER DOWNLOADER', 'On the next page open the folder/link then select press menu key or C and select download from Cloud.')
	elif dialog==1:
		dialog = xbmcgui.Dialog().select('FEN Downloader', ['FEN Links','FEN Torrents'])	
		if dialog==0:
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.fen/?mode=real_debrid.rd_downloads,return)')
			xbmcgui.Dialog().ok('FEN DOWNLOADER','On the next page press menu key or C on the link you want to download and select download.')		
		elif dialog==1:	
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.fen/?mode=real_debrid.rd_torrent_cloud,return)')
			xbmcgui.Dialog().ok('FEN DOWNLOADER','On the next page open the folder then select press menu key or C and select download File.')

elif dialog==5:
	dialog = xbmcgui.Dialog().select('SELECT YOUR BOX TO DOWNLOAD THE FILES', ['Tanix TX5 & TX3','Tanix TX9','Vorke Z6 Plus','X96 Max','Beelink MXIII II'])

	if dialog==0:
		#TX 3 or 5
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/TX3_5/storage/.config/vfd.conf','storage/.config/vfd.conf')
		dialog = xbmcgui.Dialog()
		dialog.notification('CONFIGURATION SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('reboot')	
	elif dialog==2:
		#TX 9
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/TX9/storage/.config/vfd.conf','storage/.config/vfd.conf')
		dialog = xbmcgui.Dialog()
		dialog.notification('CONFIGURATION SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('reboot')
	elif dialog==3:
		#vorke
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/Vorke/storage/.config/vfd.conf','storage/.config/vfd.conf')
		dialog = xbmcgui.Dialog()
		dialog.notification('CONFIGURATION SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('reboot')
	elif dialog==4:
		#X96 max
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/X96max/storage/.config/vfd.conf','storage/.config/vfd.conf')
		dialog = xbmcgui.Dialog()
		dialog.notification('CONFIGURATION SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('reboot')
	elif dialog==5:
		#Beelink
		xbmcvfs.copy('special://home/addons/script.kodi.settings/boxes/Beelink/storage/.config/remote.conf','storage/.config/remote.conf')
		dialog = xbmcgui.Dialog()
		dialog.notification('CONFIGURATION SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('reboot')