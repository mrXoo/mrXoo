# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))

path = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.cerestore/'))
choice = xbmcgui.Dialog().yesno('LEIA BUILD RESTORE', 'Would you like to download and fresh LEIA build now?', nolabel='NO',yeslabel='YES')
if choice == 0:
	xbmc.executebuiltin("Home")
elif choice == 1:  
	dialog = xbmcgui.Dialog()
	dialog.ok("LEIA BUILD RESTORE", "[COLOR red][B]!!!ATTENTION!!![/B][/COLOR] IT WILL TAKE SOME TIME TO COMPLETE THE DOWNLOAD PLEASE BE PATIENT")           
	if not os.path.exists('storage/.restore/'):   
		os.makedirs('storage/.restore/')          
	url = 'https://www.dropbox.com/s/kwjxxss0i6h31e3/leia.tar?dl=1'      	
	fileName = (os.path.join('storage/.restore','20210903185157.tar'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()
	dialog = xbmcgui.Dialog()
	dialog.ok("LEIA BUILD RESTORE", "[COLOR red][B]!!!ATTENTION!!![/B][/COLOR] ON NEXT BOOT FOLLOW THE PROMPT TO RESTORE YOUR PERSONAL SETTINGS. BOX WILL NOW REBOOT")
	dialog = xbmcgui.Dialog()
	dialog.ok("LEIA BUILD RESTORE", "PRESS [B]OK[/B] TO ENABLE A REBOOT [COLOR red][B]!!!WARNING!!![/B][/COLOR] DO NOT POWER OFF BOX WHEN UPDATE IS IN PROGRESS")
	time.sleep(2)	
	xbmc.executebuiltin('Reboot')
	#xbmc.executebuiltin("Home")