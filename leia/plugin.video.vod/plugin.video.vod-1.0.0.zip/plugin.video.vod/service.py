# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmcplugin,os,xbmcvfs
import time
import xbmc, sys
import requests

xbmc.log(repr(sys.argv))
def movies():
	root= xbmc.translatePath('special://home/userdata/playlists/video/')
	url = 'https://www.midian.appboxes.co/wolfyB/newmidian/Movies/megalist.m3u'     
	#os.makedirs(root, exist_ok=True) 		
	fileName = (os.path.join(root,'movies.m3u'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()

def tvshows():
	root= xbmc.translatePath('special://home/userdata/playlists/video/')
	url = 'https://www.midian.appboxes.co/wolfyB/newmidian/TVShows/tvseries.m3u'     
	#os.makedirs(root, exist_ok=True) 		
	fileName = (os.path.join(root,'tvshows.m3u'))
	req = requests.get(url)
	file = open(fileName, 'wb')
	for chunk in req.iter_content(100000):
		file.write(chunk)
	file.close()
	
movies()
tvshows()
xbmc.executebuiltin('library://video/playlists.xml/')
